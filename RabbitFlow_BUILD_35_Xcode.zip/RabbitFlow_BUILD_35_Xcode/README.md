# RabbitFlow Build 31 — Premium Subscription Trial

Base: RabbitFlow Build 30.

- Preserves the approved RabbitFlow UI, artwork, logo, pedigree, duties, and navigation.
- Keeps iPhone + iPad support (TARGETED_DEVICE_FAMILY 1,2), iOS 17+, and the existing RabbitFlow bundle identity.
- Uses the App Store Connect product IDs `rabbitflow.premium.monthly` and `rabbitflow.premium.yearly`.
- Displays localized StoreKit prices for the monthly and yearly auto-renewable plans, the seven-day introductory trial notice, purchase, and restore actions.
- Checks verified, unexpired StoreKit entitlements at launch and foreground activation. Existing rabbit data remains on device when access ends.
- Mirrors QuailFlow's DEBUG/TestFlight full-access behavior using the sandbox App Store receipt.
- Adds the approved Records rows: Pedigrees & Print, Reports, Photos & Documents, Notes.
- New Records storage fields are optional in the saved snapshot so existing RabbitFlow data remains backward-compatible.
- Does not copy QuailFlow branding, quail data, or QuailFlow product identifiers.

Before App Review: upload this build from Xcode, add genuine iPhone and iPad screenshots, complete the app privacy and review details, attach the two subscriptions to version 1.0, and supply a Privacy Policy URL. The subscription review screenshots should show this paywall. Apple will present the exact introductory trial eligibility and renewal terms at purchase. The DEBUG/TestFlight bypass grants full access to testers; test purchases with a dedicated StoreKit test configuration or a non-bypass sandbox build before public release.
