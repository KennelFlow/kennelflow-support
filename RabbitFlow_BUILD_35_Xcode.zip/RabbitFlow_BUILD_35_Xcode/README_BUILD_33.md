# RabbitFlow Build 33 — QuailFlow QR/NFC Programming Parity

Base: RabbitFlow Build 32.

Adds the QuailFlow smart-access workflow adapted for RabbitFlow:
- Program New NFC Tag
- Generate / Assign QR Code
- View QR Code
- Print QR
- Share QR
- Replace / Reassign
- Assigned Smart Access library
- Existing Rabbit, Cage/Hutch, and Area targets
- Create a new Cage/Hutch or Area during assignment
- Real NDEF NFC writing with rabbitflow://tag/<code>
- QR and NFC share the same unique RabbitFlow access link
- Branded QR generation using RabbitFlow artwork
- Manual code lookup
- Scan matching through the new Smart Access records
- Backward-compatible storage; existing Build 32 data remains readable

Approved Home layout and unrelated RabbitFlow features remain unchanged.
