# RabbitFlow Build 35

Pedigree/print repair build based on Build 34.

- Replaces the placeholder More > Pedigrees & Print screen with the real rabbit pedigree library.
- Adds visible Sire and Dam selectors to rabbit Add/Edit.
- Adds a full 5-generation pedigree editor (62 ancestor positions across generations 1-5).
- Converts the printable/display pedigree from 3 generations to 5 generations.
- Keeps RabbitFlow pedigree branding/watermark.
- Fixes printing presentation for both iPhone and iPad.
- Keeps PDF share/export.
- Extends pedigree text parsing to recognize lineage labels through five generations.
- Preserves all unrelated approved RabbitFlow features.
