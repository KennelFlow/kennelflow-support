# RabbitFlow Build 34

Base: Build 33.

Changes:
- Adds a visible Edit Smart Access control on every QR/NFC assignment.
- Adds a visible Delete Smart Access control with confirmation.
- Keeps Replace / Reassign on every assignment.
- Keeps Program NFC, View QR, Print QR, and Share QR.
- Delete removes only the smart-access assignment, not the rabbit/cage record.
- Preserves the approved RabbitFlow layout and all unrelated features.
- Build number 34.
