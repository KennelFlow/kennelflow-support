# RabbitFlow Build 32

Base: accepted RabbitFlow Build 31.

Changes only:
- Adds a RabbitFlow Smart System section in More.
- Adds Order NFC Smart System -> https://rabbitflow.app/shop.html
- Adds Open RabbitFlow Website -> https://rabbitflow.app
- Preserves the approved RabbitFlow Home screen and all existing app workflows.
- Build number advanced to 32.
