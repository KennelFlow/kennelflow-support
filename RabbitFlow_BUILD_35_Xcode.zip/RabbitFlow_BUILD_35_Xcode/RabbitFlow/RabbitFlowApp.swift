import SwiftUI
import StoreKit

enum RabbitFlowBetaAccess {
    static var grantsFullProAccess: Bool {
        #if DEBUG
        return true
        #else
        guard let receiptURL = Bundle.main.appStoreReceiptURL else { return false }
        return receiptURL.lastPathComponent == "sandboxReceipt"
        #endif
    }
}

@MainActor
final class RabbitFlowSubscriptionManager: ObservableObject {
    static let monthlyProductID = "rabbitflow.premium.monthly"
    static let annualProductID = "rabbitflow.premium.yearly"
    private static let productIDs: Set<String> = [monthlyProductID, annualProductID]
    @Published private(set) var products: [Product] = []
    @Published private(set) var hasPaidEntitlement = false
    @Published private(set) var hasCheckedEntitlements = false
    @Published private(set) var isLoading = false
    @Published var errorMessage: String?
    private var transactionListener: Task<Void, Never>?
    var hasProAccess: Bool { RabbitFlowBetaAccess.grantsFullProAccess || hasPaidEntitlement }
    init() { transactionListener = listenForTransactions(); Task { await refresh() } }
    deinit { transactionListener?.cancel() }
    func refresh() async {
        isLoading = true; defer { isLoading = false; hasCheckedEntitlements = true }; errorMessage = nil
        do { products = try await Product.products(for: Array(Self.productIDs)).sorted { lhs, rhs in
            if lhs.id == Self.monthlyProductID { return true }; if rhs.id == Self.monthlyProductID { return false }; return lhs.displayPrice < rhs.displayPrice
        }} catch { errorMessage = error.localizedDescription }
        var entitled = false
        for await result in Transaction.currentEntitlements {
            guard case .verified(let transaction) = result,
                  Self.productIDs.contains(transaction.productID),
                  transaction.revocationDate == nil,
                  transaction.expirationDate.map({ $0 > Date() }) ?? false else { continue }
            entitled = true
        }
        hasPaidEntitlement = entitled
    }
    func purchase(_ product: Product) async {
        isLoading = true; defer { isLoading = false }; errorMessage = nil
        do {
            let result = try await product.purchase()
            switch result {
            case .success(.verified(let transaction)): await transaction.finish(); await refresh()
            case .success(.unverified(_, let error)): errorMessage = error.localizedDescription
            case .pending: errorMessage = "Purchase is pending approval."
            case .userCancelled: break
            @unknown default: break
            }
        } catch { errorMessage = error.localizedDescription }
    }
    func restorePurchases() async {
        isLoading = true; defer { isLoading = false }; errorMessage = nil
        do { try await AppStore.sync(); await refresh() } catch { errorMessage = error.localizedDescription }
    }
    private func listenForTransactions() -> Task<Void, Never> { Task { [weak self] in for await result in Transaction.updates { guard case .verified(let transaction) = result else { continue }; await transaction.finish(); await self?.refresh() } } }
}

@main
struct RabbitFlowApp: App {
    @Environment(\.scenePhase) private var scenePhase
    @StateObject private var store = RabbitFlowStore()
    @StateObject private var subscriptions = RabbitFlowSubscriptionManager()
    var body: some Scene {
        WindowGroup {
            Group {
                if !subscriptions.hasCheckedEntitlements && !RabbitFlowBetaAccess.grantsFullProAccess {
                    ProgressView("Checking RabbitFlow access…")
                        .frame(maxWidth: .infinity, maxHeight: .infinity)
                } else if subscriptions.hasProAccess {
                    RootView()
                } else {
                    RabbitFlowPaywall()
                }
            }
            .environmentObject(store)
            .environmentObject(subscriptions)
            .task { await subscriptions.refresh() }
            .onChange(of: scenePhase) { _, phase in
                if phase == .active { Task { await subscriptions.refresh() } }
            }
        }
    }
}

private struct RabbitFlowPaywall: View {
    @EnvironmentObject private var subscriptions: RabbitFlowSubscriptionManager

    var body: some View {
        ZStack {
            RabbitFlowBackground()
            ScrollView {
                VStack(spacing: 20) {
                    Image("RabbitFlowBrandMark")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 130, height: 130)
                        .accessibilityHidden(true)
                    Text("RabbitFlow Premium")
                        .font(.largeTitle.bold())
                        .foregroundStyle(.white)
                    Text("Keep your rabbit records, breeding, litters, pedigrees, and daily care together.")
                        .multilineTextAlignment(.center)
                        .foregroundStyle(.white)

                    if subscriptions.products.isEmpty {
                        Text(subscriptions.isLoading ? "Loading plans…" : "Plans are unavailable right now. Please try again.")
                            .foregroundStyle(.white)
                        Button("Try Again") { Task { await subscriptions.refresh() } }
                            .disabled(subscriptions.isLoading)
                    } else {
                        Text("Eligible new subscribers get 7 days free. Apple will show the exact trial terms before you subscribe. Cancel before the trial ends to avoid a charge.")
                            .font(.subheadline)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white)
                        ForEach(subscriptions.products, id: \.id) { product in
                            Button {
                                Task { await subscriptions.purchase(product) }
                            } label: {
                                HStack {
                                    VStack(alignment: .leading) {
                                        Text(product.id == RabbitFlowSubscriptionManager.monthlyProductID ? "Monthly" : "Yearly")
                                            .font(.headline)
                                        Text(product.id == RabbitFlowSubscriptionManager.monthlyProductID ? "Renews each month" : "Renews each year")
                                            .font(.caption)
                                    }
                                    Spacer()
                                    Text(product.displayPrice + (product.id == RabbitFlowSubscriptionManager.monthlyProductID ? "/month" : "/year"))
                                        .font(.headline)
                                }
                                .padding(16)
                                .foregroundStyle(Color.rfDeepGreen)
                                .background(Color.rfCream, in: RoundedRectangle(cornerRadius: 16))
                            }
                            .disabled(subscriptions.isLoading)
                        }
                    }

                    if let error = subscriptions.errorMessage {
                        Text(error).font(.caption).foregroundStyle(.white)
                    }
                    Button("Restore Purchases") { Task { await subscriptions.restorePurchases() } }
                        .disabled(subscriptions.isLoading)
                        .foregroundStyle(.white)
                    Link("Terms of Use", destination: URL(string: "https://www.apple.com/legal/internet-services/itunes/dev/stdeula/")!)
                        .font(.caption)
                        .foregroundStyle(.white)
                }
                .padding(24)
                .frame(maxWidth: 540)
                .frame(maxWidth: .infinity)
            }
        }
    }
}
