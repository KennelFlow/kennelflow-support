import Foundation

struct Rabbit: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var name: String
    var tattooID: String
    var sex: RabbitSex
    var dateOfBirth: Date
    var breed: String
    var variety: String
    var weight: Double
    var status: RabbitStatus
    var registrationNumber: String
    var breederSource: String
    var purchasePrice: Double
    var cageID: UUID?
    var sireID: UUID?
    var damID: UUID?
    var notes: String
    var photoData: Data? = nil
}

enum RabbitSex: String, CaseIterable, Codable, Identifiable, Sendable {
    case buck = "Buck"
    case doe = "Doe"
    var id: String { rawValue }
}

enum RabbitStatus: String, CaseIterable, Codable, Identifiable, Sendable {
    case active = "Active"
    case breeding = "Breeding"
    case growOut = "Grow-Out"
    case forSale = "For Sale"
    case retired = "Retired"
    case deceased = "Deceased"
    var id: String { rawValue }
}

struct BreedingRecord: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var doeID: UUID?
    var buckID: UUID?
    var breedingDate: Date
    var attemptCount: Int
    var palpationDate: Date?
    var expectedKindlingDate: Date
    var nestBoxDate: Date
    var actualKindlingDate: Date?
    var liveKits: Int
    var stillborn: Int
    var fosteredKits: Int
    var notes: String
}

struct LitterRecord: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var litterID: String
    var doeID: UUID?
    var buckID: UUID?
    var dateOfBirth: Date
    var bornCount: Int
    var liveCount: Int
    var weaningDate: Date?
    var notes: String
}

struct CageRecord: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var name: String
    var qrValue: String
    var nfcValue: String
    var rabbitID: UUID?
    var notes: String
}

struct SmartAccessRecord: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var code: String = UUID().uuidString
    var label: String
    var entityType: String
    var entityID: UUID?
    var entityName: String
    var tagType: String = "QR + NFC"
    var notes: String
    var createdAt: Date = Date()
    var updatedAt: Date = Date()

    var accessLink: String { "rabbitflow://tag/\(code)" }
    var displayName: String { label.isEmpty ? entityName : label }
}

struct DutyRecord: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var date: Date
    var shift: CareShift
    var task: String
    var completed: Bool
    var completedAt: Date?
}

enum CareShift: String, CaseIterable, Codable, Identifiable, Sendable {
    case morning = "Morning"
    case evening = "Evening"
    case night = "Night"
    var id: String { rawValue }
}

struct SimpleRecord: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var title: String
    var detail: String
    var date: Date
    var amount: Double?
}

struct BreedCatalog {
    static let breeds: [String: [String]] = [
        "New Zealand": ["White", "Black", "Blue", "Red", "Broken"],
        "Californian": ["Standard"],
        "Rex": ["Amber", "Black", "Blue", "Broken", "Californian", "Castor", "Chinchilla", "Chocolate", "Lilac", "Lynx", "Opal", "Otter", "Red", "Sable", "Seal", "White"],
        "Mini Rex": ["Black", "Blue", "Broken", "Castor", "Chinchilla", "Chocolate", "Himalayan", "Lilac", "Lynx", "Opal", "Otter", "Red", "Sable Point", "Seal", "Tortoise", "White"],
        "Flemish Giant": ["Black", "Blue", "Fawn", "Light Gray", "Sandy", "Steel Gray", "White"],
        "Dutch": ["Black", "Blue", "Chinchilla", "Chocolate", "Gray", "Steel", "Tortoise"],
        "Holland Lop": ["Agouti", "Broken", "Pointed White", "Self", "Shaded", "Tan Pattern", "Ticked", "Wide Band"],
        "Mini Lop": ["Agouti", "Broken", "Pointed White", "Self", "Shaded", "Tan Pattern", "Ticked", "Wide Band"],
        "Lionhead": ["Tortoise", "Ruby Eyed White", "Black", "Chocolate", "Blue", "Broken"],
        "Silver Fox": ["Black", "Blue"],
        "Champagne d'Argent": ["Standard"],
        "Checkered Giant": ["Black", "Blue"]
    ]
}

struct PedigreeDocument: Identifiable, Codable, Hashable, Sendable {
    var id = UUID()
    var rabbitID: UUID
    var fileName: String
    var importedAt: Date = Date()
    var data: Data
    var extractedText: String = ""
}
