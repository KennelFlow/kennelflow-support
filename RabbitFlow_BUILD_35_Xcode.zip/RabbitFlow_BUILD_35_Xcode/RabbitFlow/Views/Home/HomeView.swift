import SwiftUI

struct HomeView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Binding var showScanner: Bool
    @Binding var tabSelection: Int

    private var activeRabbits: [Rabbit] { store.rabbits.filter { $0.status != .deceased } }
    private var bucks: Int { activeRabbits.filter { $0.sex == .buck }.count }
    private var does: Int { activeRabbits.filter { $0.sex == .doe }.count }
    private var available: Int { store.rabbits.filter { $0.status == .forSale }.count }
    private var bred: Int { Set(store.breedings.filter { $0.actualKindlingDate == nil }.compactMap(\.doeID)).count }
    private var dueSoon: Int {
        let now = Date()
        let limit = Calendar.current.date(byAdding: .day, value: 7, to: now) ?? now
        return store.breedings.filter {
            $0.actualKindlingDate == nil && $0.expectedKindlingDate >= now && $0.expectedKindlingDate <= limit
        }.count
    }

    var body: some View {
        ZStack {
            RabbitFlowBackground()
            ScrollView(showsIndicators: false) {
                VStack(spacing: 8) {
                    hero
                    scanButton
                    metrics
                    todaysCare
                    homeTagline
                }
                .padding(.bottom, 112)
            }
        }
        .toolbar(.hidden, for: .navigationBar)
    }

    // Uses the approved RabbitFlow artwork without baked-in controls.
    // This prevents duplicate Scan buttons and removes the nonfunctional bell from the hero image.
    private var hero: some View {
        GeometryReader { proxy in
            Image("RabbitFlowHomeHero")
                .resizable()
                .scaledToFit()
                .frame(width: proxy.size.width, alignment: .top)
                .accessibilityHidden(true)
        }
        // Keep the approved artwork's full 851:545 composition visible.
        // Do not crop RabbitFlow, the tagline, rabbits, or scenery.
        .aspectRatio(851.0 / 545.0, contentMode: .fit)
        .frame(maxWidth: .infinity)
    }

    private var scanButton: some View {
        Button { showScanner = true } label: {
            HStack(spacing: 14) {
                Image(systemName: "qrcode.viewfinder")
                    .font(.system(size: 26, weight: .bold))
                Text("Scan QR / NFC")
                    .font(.system(size: 21, weight: .bold))
                Spacer()
                Image(systemName: "chevron.right")
                    .font(.system(size: 18, weight: .bold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 26)
            .frame(height: 56)
            .background(
                LinearGradient(colors: [Color.rfForest, Color.rfDeepGreen], startPoint: .leading, endPoint: .trailing),
                in: Capsule()
            )
            .overlay(Capsule().stroke(Color.white.opacity(0.32), lineWidth: 1))
            .shadow(color: .black.opacity(0.25), radius: 9, y: 4)
        }
        .buttonStyle(.plain)
        .padding(.horizontal, 34)
        .padding(.top, 2)
    }

    private var metrics: some View {
        LazyVGrid(columns: Array(repeating: GridItem(.flexible(), spacing: 8), count: 4), spacing: 8) {
            DashboardMetric(title: "Total Rabbits", value: activeRabbits.count, icon: "hare.fill") { tabSelection = 1 }
            DashboardMetric(title: "Bucks", value: bucks, icon: "hare.fill", badge: "♂") { tabSelection = 1 }
            DashboardMetric(title: "Does", value: does, icon: "hare.fill", badge: "♀") { tabSelection = 1 }
            DashboardMetric(title: "Litters", value: store.litters.count, icon: "pawprint.fill") { tabSelection = 3 }
            DashboardMetric(title: "Kits Available", value: available, icon: "hare.fill") { tabSelection = 3 }
            DashboardMetric(title: "Does Bred", value: bred, icon: "heart.fill") { tabSelection = 2 }
            DashboardMetric(title: "Does Due Soon", value: dueSoon, icon: "calendar") { tabSelection = 2 }
            DashboardMetric(title: "Grow-Out Rabbits", value: store.growOut.count, icon: "hare.fill") { tabSelection = 1 }
        }
        .padding(.horizontal, 12)
    }

    private var todaysCare: some View {
        VStack(spacing: 0) {
            HStack {
                Text("Today’s Care")
                    .font(.title3.bold())
                Spacer()
                Text(Date.now.formatted(.dateTime.weekday(.abbreviated).month(.abbreviated).day().year()))
                    .font(.caption.weight(.semibold))
            }
            .foregroundStyle(.white)
            .padding(.horizontal, 14)
            .frame(height: 48)
            .background(Color.rfForest)

            HStack(spacing: 8) {
                shiftCard(.morning, icon: "sun.max.fill")
                shiftCard(.evening, icon: "sun.horizon.fill")
                shiftCard(.night, icon: "moon.fill")
            }
            .padding(10)
            .background(Color.rfCream)

            NavigationLink {
                DutiesView()
            } label: {
                HStack(spacing: 10) {
                    Image(systemName: "list.bullet.clipboard.fill")
                        .font(.system(size: 18, weight: .semibold))
                    Text("View All Duties")
                        .font(.subheadline.bold())
                    Spacer()
                    Image(systemName: "chevron.right")
                        .font(.system(size: 14, weight: .bold))
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 16)
                .frame(height: 46)
                .background(Color.rfDeepGreen)
            }
            .buttonStyle(.plain)
            .padding(.horizontal, 10)
            .padding(.bottom, 10)
            .background(Color.rfCream)
        }
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
        .shadow(color: .black.opacity(0.18), radius: 8, y: 4)
        .padding(.horizontal, 12)
    }

    private func shiftCard(_ careShift: CareShift, icon: String) -> some View {
        let duties = todayDuties.filter { $0.shift == careShift }
        let complete = duties.filter(\.completed).count
        let total = duties.count
        let progress = total == 0 ? 0.0 : Double(complete) / Double(total)

        return NavigationLink {
            DutiesView(initialShift: careShift)
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon)
                    .font(.system(size: 18, weight: .semibold))
                    .foregroundStyle(Color.rfForest)

                Text(careShift.rawValue)
                    .font(.system(size: 11, weight: .bold))
                    .foregroundStyle(Color.rfDeepGreen)

                ZStack {
                    Circle()
                        .stroke(Color.rfDeepGreen.opacity(0.13), lineWidth: 5)
                    Circle()
                        .trim(from: 0, to: progress)
                        .stroke(Color.rfForest, style: StrokeStyle(lineWidth: 5, lineCap: .round))
                        .rotationEffect(.degrees(-90))
                    Text("\(complete)/\(total)")
                        .font(.system(size: 12, weight: .bold))
                        .foregroundStyle(.primary)
                }
                .frame(width: 48, height: 48)

                Text(total == 1 ? "1 duty" : "\(total) duties")
                    .font(.system(size: 9.5, weight: .medium))
                    .foregroundStyle(.secondary)

                Image(systemName: "chevron.right")
                    .font(.system(size: 9, weight: .bold))
                    .foregroundStyle(Color.rfDeepGreen.opacity(0.75))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 126)
            .background(Color.white.opacity(0.72), in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14, style: .continuous).stroke(Color.rfDeepGreen.opacity(0.12), lineWidth: 1))
            .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }


    private var homeTagline: some View {
        VStack(spacing: 10) {
            Image(systemName: "hare.fill")
                .font(.system(size: 42, weight: .regular))
                .foregroundStyle(Color.white.opacity(0.07))
                .accessibilityHidden(true)

            Text("Better Rabbits. A Brighter Tomorrow.")
                .font(.system(size: 20, weight: .medium, design: .serif).italic())
                .foregroundStyle(Color.rfWarmCream.opacity(0.96))
                .multilineTextAlignment(.center)

            Rectangle()
                .fill(Color.rfWarmCream.opacity(0.55))
                .frame(width: 210, height: 1)
        }
        .frame(maxWidth: .infinity)
        .padding(.top, 12)
        .padding(.bottom, 2)
        .accessibilityElement(children: .combine)
    }

    private var todayDuties: [DutyRecord] {
        store.duties.filter { Calendar.current.isDateInToday($0.date) }
    }
}

private struct DashboardMetric: View {
    let title: String
    let value: Int
    let icon: String
    var badge: String? = nil
    let action: () -> Void

    var body: some View {
        Button(action: action) {
            VStack(spacing: 4) {
                HStack(spacing: 2) {
                    Image(systemName: icon)
                    if let badge { Text(badge).font(.caption.bold()) }
                }
                .font(.title3.weight(.semibold))
                .foregroundStyle(Color.rfDeepGreen)
                .frame(height: 24)

                Text("\(value)")
                    .font(.title2.bold())
                    .foregroundStyle(.primary)

                HStack(spacing: 2) {
                    Text(title)
                        .font(.system(size: 9.5, weight: .semibold))
                        .lineLimit(2)
                        .multilineTextAlignment(.center)
                        .minimumScaleFactor(0.7)
                    Image(systemName: "chevron.right")
                        .font(.system(size: 9, weight: .bold))
                }
                .foregroundStyle(.primary.opacity(0.82))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 78)
            .padding(.horizontal, 2)
            .background(Color.rfCream, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 14).stroke(Color.white.opacity(0.55), lineWidth: 1))
            .shadow(color: .black.opacity(0.12), radius: 5, y: 2)
            .contentShape(RoundedRectangle(cornerRadius: 14, style: .continuous))
        }
        .buttonStyle(.plain)
    }
}
