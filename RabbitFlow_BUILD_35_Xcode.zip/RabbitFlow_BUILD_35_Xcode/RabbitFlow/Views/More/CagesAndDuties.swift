import SwiftUI

struct CagesView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var showAdd = false
    @State private var edit: CageRecord?

    var body: some View {
        Group {
            if store.cages.isEmpty { EmptyState(icon: "square.grid.3x3", title: "No Cages Yet", message: "Create cages or hutches and assign rabbits to them.") }
            else {
                List {
                    ForEach(store.cages) { cage in
                        Button { edit = cage } label: {
                            VStack(alignment: .leading) {
                                Text(cage.name).font(.headline)
                                Text(store.rabbitName(cage.rabbitID)).font(.caption).foregroundStyle(.secondary)
                            }
                        }.buttonStyle(.plain)
                    }.onDelete { store.cages.remove(atOffsets: $0) }
                }
            }
        }
        .navigationTitle("Cages")
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showAdd = true } label: { Image(systemName: "plus") } } }
        .sheet(isPresented: $showAdd) { NavigationStack { CageForm(record: nil) } }
        .sheet(item: $edit) { record in NavigationStack { CageForm(record: record) } }
    }
}

struct CageForm: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) var dismiss
    let record: CageRecord?
    @State private var name = ""
    @State private var rabbitID: UUID?
    @State private var qrValue = UUID().uuidString
    @State private var nfcValue = UUID().uuidString
    @State private var notes = ""

    var body: some View {
        Form {
            TextField("Cage / Hutch Name", text: $name)
            Picker("Rabbit", selection: $rabbitID) {
                Text("Unassigned").tag(UUID?.none)
                ForEach(store.rabbits) { Text($0.name.isEmpty ? $0.tattooID : $0.name).tag(UUID?.some($0.id)) }
            }
            Section("Smart Rabbit Access") {
                if let record,
                   let access = store.smartAccess.first(where: { $0.entityType == "Cage / Hutch" && $0.entityID == record.id }) {
                    RabbitQRCodeView(text: access.accessLink)
                        .frame(width: 150, height: 150)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 6)
                    NavigationLink {
                        AccessDetailView(accessID: access.id)
                    } label: {
                        Label("Open Smart Rabbit Access", systemImage: "qrcode.viewfinder")
                    }
                    Text("QR is generated automatically for this cage / hutch. NFC uses the same unique RabbitFlow link and is programmed from Smart Rabbit Access.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                } else {
                    Label("Smart QR / NFC access is created automatically when this cage / hutch is saved.", systemImage: "qrcode")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }
            TextField("Notes", text: $notes, axis: .vertical)
        }
        .navigationTitle(record == nil ? "Add Cage" : "Edit Cage").navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement: .cancellationAction){Button("Cancel"){dismiss()}}; ToolbarItem(placement:.confirmationAction){Button("Save"){save()}.disabled(name.trimmingCharacters(in:.whitespaces).isEmpty)} }
        .onAppear { guard let r=record else{return}; name=r.name;rabbitID=r.rabbitID;qrValue=r.qrValue;nfcValue=r.nfcValue;notes=r.notes }
    }
    private func save() {
        let cageID = record?.id ?? UUID()
        let updated = CageRecord(
            id: cageID,
            name: name,
            qrValue: qrValue,
            nfcValue: nfcValue,
            rabbitID: rabbitID,
            notes: notes
        )
        if let i = store.cages.firstIndex(where: { $0.id == cageID }) {
            store.cages[i] = updated
        } else {
            store.cages.append(updated)
        }
        _ = store.ensureSmartAccess(
            label: name,
            entityType: "Cage / Hutch",
            entityID: cageID,
            entityName: notes.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? name : notes,
            notes: "Automatic RabbitFlow smart access for this cage / hutch."
        )
        dismiss()
    }
}

struct DutiesView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var task = ""
    @State private var shift: CareShift

    init(initialShift: CareShift = .morning) {
        _shift = State(initialValue: initialShift)
    }

    var body: some View {
        ScrollView {
            VStack(spacing: 10) {
                addDutyCard

                ForEach(CareShift.allCases) { careShift in
                    dutySection(careShift)
                }

                NavigationLink { DutyHistoryView() } label: {
                    HStack(spacing: 10) {
                        Image(systemName: "doc.text.fill")
                            .font(.system(size: 18, weight: .semibold))
                        Text("View All Duty Records")
                            .font(.system(size: 16, weight: .bold))
                        Spacer(minLength: 6)
                        Image(systemName: "chevron.right")
                            .font(.system(size: 14, weight: .bold))
                    }
                    .foregroundStyle(.white)
                    .padding(.horizontal, 14)
                    .frame(height: 46)
                    .background(Color.rfForest, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                }
                .buttonStyle(.plain)
            }
            .padding(.horizontal, 14)
            .padding(.top, 8)
            .padding(.bottom, 10)
        }
        .scrollDismissesKeyboard(.interactively)
        .background(Color.rfWarmCream.ignoresSafeArea())
        .navigationTitle("Daily Duties")
        .navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
    }

    private var addDutyCard: some View {
        VStack(spacing: 0) {
            HStack(spacing: 10) {
                Text("Select Shift")
                    .font(.system(size: 17, weight: .bold))
                    .foregroundStyle(Color.rfDeepGreen)
                Spacer(minLength: 8)
                Picker("Shift", selection: $shift) {
                    ForEach(CareShift.allCases) { Text($0.rawValue).tag($0) }
                }
                .labelsHidden()
                .tint(Color.rfForest)
            }
            .padding(.horizontal, 14)
            .frame(height: 40)

            Divider().padding(.horizontal, 14)

            TextField("Task", text: $task)
                .font(.system(size: 16))
                .padding(.horizontal, 14)
                .frame(height: 40)

            Divider().padding(.horizontal, 14)

            Button(action: addDuty) {
                HStack(spacing: 8) {
                    Image(systemName: "plus.circle.fill")
                        .font(.system(size: 18, weight: .semibold))
                    Text("Add Duty")
                        .font(.system(size: 16, weight: .bold))
                    Spacer()
                }
                .foregroundStyle(.white)
                .padding(.horizontal, 14)
                .frame(height: 42)
                .background(Color.rfForest, in: RoundedRectangle(cornerRadius: 11, style: .continuous))
            }
            .buttonStyle(.plain)
            .disabled(task.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            .opacity(task.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty ? 0.45 : 1)
            .padding(8)
        }
        .background(Color.white.opacity(0.94), in: RoundedRectangle(cornerRadius: 18, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(Color.rfDeepGreen.opacity(0.10), lineWidth: 1))
        .shadow(color: .black.opacity(0.05), radius: 4, y: 2)
    }

    @ViewBuilder
    private func dutySection(_ careShift: CareShift) -> some View {
        let rows = today.filter { $0.shift == careShift }
        let completedCount = rows.filter(\.completed).count

        VStack(alignment: .leading, spacing: 5) {
            HStack(spacing: 8) {
                Image(systemName: shiftIcon(for: careShift))
                    .font(.system(size: 16, weight: .semibold))
                    .foregroundStyle(Color.rfForest)
                    .frame(width: 20)

                Text(careShift.rawValue)
                    .font(.system(size: 18, weight: .bold))
                    .foregroundStyle(Color.rfDeepGreen)

                Spacer(minLength: 8)

                Text("\(completedCount) of \(rows.count) complete")
                    .font(.system(size: 12, weight: .semibold))
                    .foregroundStyle(Color.rfDeepGreen.opacity(0.76))
            }
            .padding(.horizontal, 8)

            VStack(spacing: 0) {
                if rows.isEmpty {
                    HStack(spacing: 10) {
                        Image(systemName: "circle")
                            .font(.system(size: 17))
                            .foregroundStyle(.secondary)
                        Text("No tasks")
                            .font(.system(size: 16))
                            .foregroundStyle(.secondary)
                        Spacer()
                    }
                    .padding(.horizontal, 14)
                    .frame(height: 42)
                } else {
                    ForEach(Array(rows.enumerated()), id: \.element.id) { index, duty in
                        Button { toggle(duty) } label: {
                            HStack(spacing: 11) {
                                Image(systemName: duty.completed ? "checkmark.circle.fill" : "circle")
                                    .font(.system(size: 20, weight: .medium))
                                    .foregroundStyle(duty.completed ? Color.rfForest : Color.primary)

                                Text(duty.task)
                                    .font(.system(size: 16, weight: .medium))
                                    .foregroundStyle(.primary)
                                    .strikethrough(duty.completed)
                                    .lineLimit(1)

                                Spacer(minLength: 4)
                            }
                            .padding(.horizontal, 14)
                            .frame(height: 42)
                            .contentShape(Rectangle())
                        }
                        .buttonStyle(.plain)
                        .contextMenu {
                            Button(role: .destructive) { delete(duty) } label: {
                                Label("Delete Duty", systemImage: "trash")
                            }
                        }

                        if index < rows.count - 1 {
                            Divider().padding(.leading, 48)
                        }
                    }
                }
            }
            .background(Color.white.opacity(0.94), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
            .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(Color.rfDeepGreen.opacity(0.08), lineWidth: 1))
            .shadow(color: .black.opacity(0.04), radius: 3, y: 1)
        }
    }

    private func shiftIcon(for careShift: CareShift) -> String {
        switch careShift {
        case .morning: return "sun.max.fill"
        case .evening: return "sunset.fill"
        case .night: return "moon.fill"
        }
    }

    private var today: [DutyRecord] {
        store.duties.filter { Calendar.current.isDateInToday($0.date) }
    }

    private func addDuty() {
        let clean = task.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !clean.isEmpty else { return }
        store.duties.append(DutyRecord(date: Date(), shift: shift, task: clean, completed: false, completedAt: nil))
        task = ""
    }

    private func toggle(_ duty: DutyRecord) {
        guard let i = store.duties.firstIndex(where: { $0.id == duty.id }) else { return }
        store.duties[i].completed.toggle()
        store.duties[i].completedAt = store.duties[i].completed ? Date() : nil
    }

    private func delete(_ duty: DutyRecord) {
        store.duties.removeAll { $0.id == duty.id }
    }
}

struct DutyHistoryView: View {
    @EnvironmentObject var store: RabbitFlowStore

    var body: some View {
        List(store.duties.sorted { $0.date > $1.date }) { duty in
            VStack(alignment: .leading) {
                Text("\(duty.shift.rawValue): \(duty.task)")
                    .font(.headline)
                Text(duty.date.formatted(date: .abbreviated, time: .shortened))
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(duty.completed ? "Completed" : "Open")
                    .font(.caption)
            }
        }
        .navigationTitle("Duty History")
        .rabbitFlowNavigationChrome()
    }
}
