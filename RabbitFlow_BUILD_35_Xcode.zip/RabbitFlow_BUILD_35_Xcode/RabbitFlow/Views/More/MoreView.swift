import SwiftUI

struct MoreView: View {
    var body: some View {
        List {
            Section("Rabbitry") {
                NavigationLink { CagesView() } label: { Label("Rabbitry / Cage Management", systemImage: "square.grid.3x3.fill") }
                NavigationLink { TagManagerView() } label: { Label("QR / NFC Management", systemImage: "qrcode.viewfinder") }
                NavigationLink { DutiesView() } label: { Label("Daily Duties", systemImage: "checklist") }
                NavigationLink { GenericRecordsView(title: "Nest Box / Kindling", keyPath: \.nestBox, icon: "shippingbox.fill") } label: { Label("Nest Box / Kindling", systemImage: "shippingbox.fill") }
                NavigationLink { GenericRecordsView(title: "Health", keyPath: \.health, icon: "cross.case.fill") } label: { Label("Health", systemImage: "cross.case.fill") }
                NavigationLink { GenericRecordsView(title: "Feeding", keyPath: \.feeding, icon: "leaf.fill") } label: { Label("Feeding", systemImage: "leaf.fill") }
                NavigationLink { GenericRecordsView(title: "Grow-Out Management", keyPath: \.growOut, icon: "chart.line.uptrend.xyaxis") } label: { Label("Grow-Out Management", systemImage: "chart.line.uptrend.xyaxis") }
            }
            Section("Business") {
                NavigationLink { GenericRecordsView(title: "Sales", keyPath: \.sales, icon: "dollarsign.circle.fill") } label: { Label("Sales", systemImage: "dollarsign.circle.fill") }
                NavigationLink { GenericRecordsView(title: "Customers", keyPath: \.customers, icon: "person.2.fill") } label: { Label("Customers", systemImage: "person.2.fill") }
                NavigationLink { GenericRecordsView(title: "Expenses & Analytics", keyPath: \.expenses, icon: "chart.bar.fill") } label: { Label("Expenses & Analytics", systemImage: "chart.bar.fill") }
                NavigationLink { GenericRecordsView(title: "Inventory", keyPath: \.inventory, icon: "shippingbox.fill") } label: { Label("Inventory", systemImage: "shippingbox.fill") }
                NavigationLink { GenericRecordsView(title: "Calendar", keyPath: \.calendarItems, icon: "calendar") } label: { Label("Calendar", systemImage: "calendar") }
            }
            Section("Records") {
                NavigationLink { PedigreeInfoView() } label: { Label("Pedigrees & Print", systemImage: "doc.text.fill") }
                NavigationLink { GenericRecordsView(title: "Reports", keyPath: \.reports, icon: "chart.bar.doc.horizontal.fill") } label: { Label("Reports", systemImage: "chart.bar.doc.horizontal.fill") }
                NavigationLink { GenericRecordsView(title: "Photos & Documents", keyPath: \.photosDocuments, icon: "photo.on.rectangle.angled") } label: { Label("Photos & Documents", systemImage: "photo.on.rectangle.angled") }
                NavigationLink { GenericRecordsView(title: "Notes", keyPath: \.notesRecords, icon: "note.text") } label: { Label("Notes", systemImage: "note.text") }
            }

            Section("RabbitFlow Smart System") {
                Link(destination: URL(string: "https://rabbitflow.app/shop.html")!) {
                    Label("Order NFC Smart System", systemImage: "cart.fill")
                }
                Link(destination: URL(string: "https://rabbitflow.app")!) {
                    Label("Open RabbitFlow Website", systemImage: "safari.fill")
                }
            }

            // Keep the final Records row fully clear of RabbitFlow's floating tab bar.
            Section {
                Color.clear
                    .frame(height: 92)
                    .listRowBackground(Color.clear)
                    .listRowSeparator(.hidden)
                    .accessibilityHidden(true)
            }
        }
        .listSectionSpacing(22)
        .rabbitFlowScrollableBackground()
        .navigationTitle("More")
        .rabbitFlowNavigationChrome()
    }
}

struct GenericRecordsView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let title: String
    let keyPath: ReferenceWritableKeyPath<RabbitFlowStore, [SimpleRecord]>
    let icon: String
    @State private var showAdd = false
    @State private var edit: SimpleRecord?

    var body: some View {
        Group {
            if store[keyPath: keyPath].isEmpty { EmptyState(icon: icon, title: "No \(title) Records", message: "Add your first record.") }
            else { List { ForEach(store[keyPath: keyPath]) { item in Button { edit=item } label: { VStack(alignment:.leading){ Text(item.title).font(.headline); Text(item.detail).font(.caption).foregroundStyle(.secondary) } }.buttonStyle(.plain) }.onDelete { store[keyPath:keyPath].remove(atOffsets:$0) } } }
        }
        .navigationTitle(title)
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement:.topBarTrailing){ Button { showAdd=true } label:{ Image(systemName:"plus") } } }
        .sheet(isPresented:$showAdd){ NavigationStack { SimpleRecordForm(title:title, record:nil, keyPath:keyPath) } }
        .sheet(item:$edit){ record in NavigationStack { SimpleRecordForm(title:title, record:record, keyPath:keyPath) } }
    }
}

struct SimpleRecordForm: View {
    @EnvironmentObject var store: RabbitFlowStore; @Environment(\.dismiss) var dismiss
    let title: String; let record: SimpleRecord?; let keyPath: ReferenceWritableKeyPath<RabbitFlowStore,[SimpleRecord]>
    @State private var recordTitle=""; @State private var detail=""; @State private var date=Date(); @State private var amount=0.0
    var body: some View { Form { TextField("Title",text:$recordTitle); TextField("Details",text:$detail,axis:.vertical); DatePicker("Date",selection:$date); TextField("Amount (optional)",value:$amount,format:.number).keyboardType(.decimalPad) }
        .navigationTitle(record == nil ? "Add \(title)" : "Edit \(title)").navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement:.cancellationAction){Button("Cancel"){dismiss()}}; ToolbarItem(placement:.confirmationAction){Button("Save"){save()}.disabled(recordTitle.trimmingCharacters(in:.whitespaces).isEmpty)} }
        .onAppear { guard let r=record else{return}; recordTitle=r.title;detail=r.detail;date=r.date;amount=r.amount ?? 0 }
    }
    private func save(){ let updated=SimpleRecord(id:record?.id ?? UUID(),title:recordTitle,detail:detail,date:date,amount:amount == 0 ? nil : amount); if let i=store[keyPath:keyPath].firstIndex(where:{$0.id==updated.id}){store[keyPath:keyPath][i]=updated}else{store[keyPath:keyPath].append(updated)};dismiss() }
}

struct PedigreeInfoView: View {
    @EnvironmentObject var store: RabbitFlowStore

    var body: some View {
        Group {
            if store.rabbits.isEmpty {
                EmptyState(
                    icon: "point.3.connected.trianglepath.dotted",
                    title: "No Rabbits Yet",
                    message: "Add a rabbit first, then build or print its 5-generation pedigree."
                )
            } else {
                List {
                    Section {
                        ForEach(store.rabbits) { rabbit in
                            NavigationLink {
                                PedigreeView(rabbitID: rabbit.id)
                            } label: {
                                HStack(spacing: 12) {
                                    ZStack {
                                        RoundedRectangle(cornerRadius: 10, style: .continuous)
                                            .fill(Color.rfWarmCream)
                                        Image(systemName: "hare.fill")
                                            .foregroundStyle(Color.rfForest)
                                    }
                                    .frame(width: 44, height: 44)
                                    VStack(alignment: .leading, spacing: 2) {
                                        Text(store.displayName(rabbit))
                                            .font(.headline)
                                        Text("5-generation pedigree • View / Edit / Print / Share")
                                            .font(.caption)
                                            .foregroundStyle(.secondary)
                                    }
                                }
                            }
                        }
                    } header: {
                        Text("Rabbit Pedigrees")
                    }
                }
                .rabbitFlowScrollableBackground()
            }
        }
        .navigationTitle("Pedigrees & Print")
        .rabbitFlowNavigationChrome()
    }
}
