import SwiftUI

struct LittersView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var showAdd = false
    @State private var editing: LitterRecord?

    var body: some View {
        Group {
            if store.litters.isEmpty { EmptyState(icon: "pawprint", title: "No Litters", message: "Add a litter after kindling to track live counts and weaning.") }
            else {
                List {
                    ForEach(store.litters) { litter in
                        Button { editing = litter } label: {
                            VStack(alignment: .leading) {
                                Text(litter.litterID).font(.headline)
                                Text("\(store.rabbitName(litter.doeID)) × \(store.rabbitName(litter.buckID)) • \(litter.liveCount) live")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }.buttonStyle(.plain)
                    }.onDelete { store.litters.remove(atOffsets: $0) }
                }
            }
        }
        .navigationTitle("Litters")
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showAdd = true } label: { Image(systemName: "plus") } } }
        .sheet(isPresented: $showAdd) { NavigationStack { LitterForm(record: nil) } }
        .sheet(item: $editing) { record in NavigationStack { LitterForm(record: record) } }
    }
}

struct LitterForm: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let record: LitterRecord?
    @State private var litterID = ""; @State private var doeID: UUID?; @State private var buckID: UUID?; @State private var dob = Date(); @State private var born = 0; @State private var live = 0; @State private var notes = ""
    var body: some View {
        Form {
            Section("Litter") {
                TextField("Litter ID", text: $litterID)
                Picker("Doe", selection: $doeID) { Text("Select Doe").tag(UUID?.none); ForEach(store.rabbits.filter{$0.sex == .doe}) { Text($0.name.isEmpty ? $0.tattooID : $0.name).tag(UUID?.some($0.id)) } }
                Picker("Buck", selection: $buckID) { Text("Select Buck").tag(UUID?.none); ForEach(store.rabbits.filter{$0.sex == .buck}) { Text($0.name.isEmpty ? $0.tattooID : $0.name).tag(UUID?.some($0.id)) } }
                DatePicker("Date of Birth", selection: $dob, displayedComponents: .date)
                Stepper("Born: \(born)", value: $born, in: 0...30); Stepper("Live: \(live)", value: $live, in: 0...30)
                TextField("Notes", text: $notes, axis: .vertical)
            }
        }
        .navigationTitle(record == nil ? "Add Litter" : "Edit Litter").navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Save") { save() }.disabled(litterID.trimmingCharacters(in: .whitespaces).isEmpty) } }
        .onAppear { guard let r = record else { return }; litterID=r.litterID; doeID=r.doeID; buckID=r.buckID; dob=r.dateOfBirth; born=r.bornCount; live=r.liveCount; notes=r.notes }
    }
    private func save() {
        let updated = LitterRecord(id: record?.id ?? UUID(), litterID: litterID, doeID: doeID, buckID: buckID, dateOfBirth: dob, bornCount: born, liveCount: live, weaningDate: record?.weaningDate, notes: notes)
        if let i=store.litters.firstIndex(where:{$0.id==updated.id}) { store.litters[i]=updated } else { store.litters.append(updated) }
        dismiss()
    }
}
