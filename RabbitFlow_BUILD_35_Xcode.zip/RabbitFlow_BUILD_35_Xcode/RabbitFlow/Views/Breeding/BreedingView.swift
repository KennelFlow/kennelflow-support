import SwiftUI

struct BreedingView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var showAdd = false
    @State private var editing: BreedingRecord?

    var body: some View {
        Group {
            if store.breedings.isEmpty {
                EmptyState(icon: "heart.circle", title: "No Breeding Records", message: "Add a breeding to automatically track kindling and nest-box dates.")
            } else {
                List {
                    ForEach(store.breedings.sorted(by: { $0.breedingDate > $1.breedingDate })) { record in
                        Button { editing = record } label: {
                            VStack(alignment: .leading, spacing: 4) {
                                Text("\(store.rabbitName(record.doeID)) × \(store.rabbitName(record.buckID))").font(.headline)
                                Text("Bred \(record.breedingDate.formatted(date: .abbreviated, time: .omitted)) • Due \(record.expectedKindlingDate.formatted(date: .abbreviated, time: .omitted))")
                                    .font(.caption).foregroundStyle(.secondary)
                            }
                        }.buttonStyle(.plain)
                    }.onDelete { offsets in
                        let sorted = store.breedings.sorted(by: { $0.breedingDate > $1.breedingDate })
                        let ids = offsets.map { sorted[$0].id }
                        store.breedings.removeAll { ids.contains($0.id) }
                    }
                }
            }
        }
        .navigationTitle("Breeding")
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement: .topBarTrailing) { Button { showAdd = true } label: { Image(systemName: "plus") } } }
        .sheet(isPresented: $showAdd) { NavigationStack { BreedingForm(record: nil) } }
        .sheet(item: $editing) { record in NavigationStack { BreedingForm(record: record) } }
    }
}

struct BreedingForm: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let record: BreedingRecord?
    @State private var doeID: UUID?; @State private var buckID: UUID?; @State private var breedingDate = Date(); @State private var attempts = 1
    @State private var liveKits = 0; @State private var stillborn = 0; @State private var fostered = 0; @State private var notes = ""

    private var expectedKindling: Date { Calendar.current.date(byAdding: .day, value: 31, to: breedingDate) ?? breedingDate }
    private var nestBoxDate: Date { Calendar.current.date(byAdding: .day, value: 28, to: breedingDate) ?? breedingDate }

    var body: some View {
        Form {
            Section("Pairing") {
                Picker("Doe", selection: $doeID) { Text("Select Doe").tag(UUID?.none); ForEach(store.rabbits.filter { $0.sex == .doe }) { Text($0.name.isEmpty ? $0.tattooID : $0.name).tag(UUID?.some($0.id)) } }
                Picker("Buck", selection: $buckID) { Text("Select Buck").tag(UUID?.none); ForEach(store.rabbits.filter { $0.sex == .buck }) { Text($0.name.isEmpty ? $0.tattooID : $0.name).tag(UUID?.some($0.id)) } }
                DatePicker("Breeding Date", selection: $breedingDate, displayedComponents: .date)
                Stepper("Attempts: \(attempts)", value: $attempts, in: 1...10)
            }
            Section("Automatic Dates") {
                LabeledContent("Nest Box", value: nestBoxDate.formatted(date: .abbreviated, time: .omitted))
                LabeledContent("Expected Kindling", value: expectedKindling.formatted(date: .abbreviated, time: .omitted))
            }
            Section("Outcome") {
                Stepper("Live Kits: \(liveKits)", value: $liveKits, in: 0...30)
                Stepper("Stillborn: \(stillborn)", value: $stillborn, in: 0...30)
                Stepper("Fostered: \(fostered)", value: $fostered, in: 0...30)
                TextField("Notes", text: $notes, axis: .vertical)
            }
        }
        .navigationTitle(record == nil ? "Add Breeding" : "Edit Breeding").navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar { ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }; ToolbarItem(placement: .confirmationAction) { Button("Save") { save() }.disabled(doeID == nil || buckID == nil) } }
        .onAppear { guard let r = record else { return }; doeID=r.doeID; buckID=r.buckID; breedingDate=r.breedingDate; attempts=r.attemptCount; liveKits=r.liveKits; stillborn=r.stillborn; fostered=r.fosteredKits; notes=r.notes }
    }

    private func save() {
        let updated = BreedingRecord(id: record?.id ?? UUID(), doeID: doeID, buckID: buckID, breedingDate: breedingDate, attemptCount: attempts, palpationDate: record?.palpationDate, expectedKindlingDate: expectedKindling, nestBoxDate: nestBoxDate, actualKindlingDate: record?.actualKindlingDate, liveKits: liveKits, stillborn: stillborn, fosteredKits: fostered, notes: notes)
        if let i = store.breedings.firstIndex(where: { $0.id == updated.id }) { store.breedings[i] = updated } else { store.breedings.append(updated) }
        dismiss()
    }
}
