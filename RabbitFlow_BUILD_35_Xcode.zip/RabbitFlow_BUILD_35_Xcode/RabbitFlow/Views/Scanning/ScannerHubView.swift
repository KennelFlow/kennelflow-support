import SwiftUI
import AVFoundation
@preconcurrency import CoreNFC
import CoreImage
import CoreImage.CIFilterBuiltins
import UIKit

// MARK: - NFC read / write

@MainActor
final class RabbitNFCManager: NSObject, ObservableObject {
    enum Mode { case read, write(String) }

    @Published var result: String?
    @Published var errorMessage: String?
    @Published var isRunning = false

    private var session: NFCNDEFReaderSession?
    private var mode: Mode = .read

    var isAvailable: Bool { NFCNDEFReaderSession.readingAvailable }

    func beginRead() {
        guard isAvailable else {
            errorMessage = "NFC tag reading is not available on this device."
            return
        }
        mode = .read
        startSession(alert: "Hold the top of your iPhone near the RabbitFlow NFC tag.")
    }

    func beginWrite(code: String) {
        guard isAvailable else {
            errorMessage = "NFC tag writing is not available on this device."
            return
        }
        mode = .write(code)
        startSession(alert: "Hold the top of your iPhone near the NFC tag you want to program for RabbitFlow.")
    }

    private func startSession(alert: String) {
        result = nil
        errorMessage = nil
        isRunning = true
        let session = NFCNDEFReaderSession(delegate: self, queue: nil, invalidateAfterFirstRead: false)
        session.alertMessage = alert
        self.session = session
        session.begin()
    }

    private func finish(_ value: String, message: String) {
        result = value
        isRunning = false
        session?.alertMessage = message
        session?.invalidate()
    }

    private func fail(_ message: String) {
        errorMessage = message
        isRunning = false
        session?.invalidate(errorMessage: message)
    }
}

private final class RabbitNDEFTagBox: @unchecked Sendable {
    let tag: NFCNDEFTag
    init(_ tag: NFCNDEFTag) { self.tag = tag }
}

extension RabbitNFCManager: NFCNDEFReaderSessionDelegate {
    nonisolated func readerSession(_ session: NFCNDEFReaderSession, didInvalidateWithError error: Error) {
        Task { @MainActor in self.isRunning = false }
    }

    nonisolated func readerSession(_ session: NFCNDEFReaderSession, didDetectNDEFs messages: [NFCNDEFMessage]) {
        // Tag connection below handles both reading and writing.
    }

    nonisolated func readerSession(_ session: NFCNDEFReaderSession, didDetect tags: [NFCNDEFTag]) {
        guard let detectedTag = tags.first else { return }
        let tagBox = RabbitNDEFTagBox(detectedTag)

        session.connect(to: tagBox.tag) { error in
            if let error {
                Task { @MainActor in self.fail(error.localizedDescription) }
                return
            }

            tagBox.tag.queryNDEFStatus { status, _, error in
                if let error {
                    Task { @MainActor in self.fail(error.localizedDescription) }
                    return
                }

                Task { @MainActor in
                    switch self.mode {
                    case .read:
                        guard status != .notSupported else {
                            self.fail("This NFC tag does not support NDEF data.")
                            return
                        }

                        tagBox.tag.readNDEF { message, error in
                            if let error {
                                if status == .readWrite {
                                    Task { @MainActor in
                                        self.finish(
                                            "__RABBITFLOW_BLANK_NDEF_TAG__",
                                            message: "Blank writable NFC tag detected. Ready to program in RabbitFlow."
                                        )
                                    }
                                } else {
                                    Task { @MainActor in self.fail(error.localizedDescription) }
                                }
                                return
                            }

                            let value = Self.extractValue(from: message) ?? "__RABBITFLOW_BLANK_NDEF_TAG__"
                            let alert = value == "__RABBITFLOW_BLANK_NDEF_TAG__"
                                ? "Blank writable NFC tag detected. Ready to program in RabbitFlow."
                                : "RabbitFlow NFC tag read."
                            Task { @MainActor in self.finish(value, message: alert) }
                        }

                    case .write(let code):
                        guard status == .readWrite else {
                            self.fail("This NFC tag is not writable.")
                            return
                        }
                        guard let url = URL(string: "rabbitflow://tag/\(code)"),
                              let payload = NFCNDEFPayload.wellKnownTypeURIPayload(url: url) else {
                            self.fail("Could not create the RabbitFlow NFC payload.")
                            return
                        }

                        let message = NFCNDEFMessage(records: [payload])
                        tagBox.tag.writeNDEF(message) { error in
                            if let error {
                                Task { @MainActor in self.fail(error.localizedDescription) }
                                return
                            }
                            Task { @MainActor in
                                self.finish(
                                    "rabbitflow://tag/\(code)",
                                    message: "RabbitFlow tag programmed successfully."
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    nonisolated private static func extractValue(from message: NFCNDEFMessage?) -> String? {
        guard let record = message?.records.first else { return nil }
        if let url = record.wellKnownTypeURIPayload() { return url.absoluteString }
        if let text = record.wellKnownTypeTextPayload().0 { return text }
        return String(data: record.payload, encoding: .utf8)
    }
}

// MARK: - Scan hub

struct ScannerHubView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss

    @State private var scannedValue = ""
    @State private var destination: ScanDestination?
    @State private var showQR = false
    @StateObject private var nfc = RabbitNFCManager()

    var body: some View {
        List {
            Section("Scan") {
                Button { showQR = true } label: {
                    Label("Scan QR Code", systemImage: "qrcode.viewfinder")
                }

                Button { nfc.beginRead() } label: {
                    Label("Read NFC Tag", systemImage: "wave.3.right.circle")
                }
                .disabled(!nfc.isAvailable || nfc.isRunning)
            }

            Section("NFC") {
                NavigationLink {
                    AccessAssignmentFlowView(action: .programNFC, showsCloseButton: false)
                } label: {
                    Label("Program NFC Tag", systemImage: "wave.3.right.circle.fill")
                        .font(.headline)
                }
            }

            if !scannedValue.isEmpty {
                Section("Result") {
                    Text(scannedValue)
                        .font(.caption.monospaced())
                        .textSelection(.enabled)

                    if let destination {
                        ScanResultView(destination: destination)
                    } else {
                        Text("No RabbitFlow assignment found for this code.")
                            .foregroundStyle(.secondary)
                    }
                }
            }

            if let error = nfc.errorMessage {
                Section { Text(error).foregroundStyle(.red) }
            }

            Section {
                NavigationLink { ManualTagLookupView() } label: {
                    Label("Enter Code Manually", systemImage: "keyboard")
                }
                NavigationLink { TagManagerView() } label: {
                    Label("Manage QR / NFC Tags", systemImage: "tag.fill")
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Scan QR / NFC")
        .rabbitFlowNavigationChrome()
        .toolbar {
            ToolbarItem(placement: .topBarLeading) {
                Button("Done") { dismiss() }
            }
        }
        .sheet(isPresented: $showQR) {
            QRScannerView { value in
                showQR = false
                process(value)
            }
        }
        .onChange(of: nfc.result) { _, newValue in
            if let newValue { process(newValue) }
        }
    }

    private func process(_ raw: String) {
        scannedValue = raw
        destination = store.lookupScan(raw)
    }
}

struct ScanResultView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let destination: ScanDestination

    var body: some View {
        switch destination {
        case .rabbit(let id):
            if let rabbit = store.rabbits.first(where: { $0.id == id }) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(store.displayName(rabbit)).font(.headline)
                    Text("\(rabbit.breed) • \(rabbit.variety)")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

        case .cage(let id):
            if let cage = store.cages.first(where: { $0.id == id }) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(cage.name).font(.headline)
                    Text(store.rabbitName(cage.rabbitID))
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

        case .smartAccess(let id):
            if let access = store.accessRecord(id) {
                VStack(alignment: .leading, spacing: 3) {
                    Text(access.displayName).font(.headline)
                    Text(access.entityType)
                        .font(.caption)
                        .foregroundStyle(.secondary)
                    if !access.entityName.isEmpty {
                        Text(access.entityName)
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
    }
}

// MARK: - QuailFlow-style QR / NFC management

enum SmartAccessAction: String, Identifiable {
    case programNFC
    case assignQR

    var id: String { rawValue }

    var title: String {
        switch self {
        case .programNFC: return "Program New NFC Tag"
        case .assignQR: return "Generate / Assign QR Code"
        }
    }
}

enum AccessLibraryMode: Equatable {
    case viewQR
    case printQR
    case shareQR
}

struct TagManagerView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var assignmentAction: SmartAccessAction?

    var body: some View {
        List {
            Section("QR / NFC Management") {
                Button { assignmentAction = .programNFC } label: {
                    Label("Program New NFC Tag", systemImage: "wave.3.right.circle.fill")
                }
                Button { assignmentAction = .assignQR } label: {
                    Label("Generate / Assign QR Code", systemImage: "qrcode")
                }
                NavigationLink { AccessLibraryView(mode: .viewQR) } label: {
                    Label("View QR Code", systemImage: "qrcode.viewfinder")
                }
                NavigationLink { AccessLibraryView(mode: .printQR) } label: {
                    Label("Print QR", systemImage: "printer.fill")
                }
                NavigationLink { AccessLibraryView(mode: .shareQR) } label: {
                    Label("Share QR", systemImage: "square.and.arrow.up")
                }
                NavigationLink { ReplaceReassignView() } label: {
                    Label("Replace / Reassign", systemImage: "arrow.triangle.2.circlepath")
                }
            }

            Section("Assigned Smart Access") {
                if store.smartAccess.isEmpty {
                    ContentUnavailableView(
                        "No QR / NFC Access Assigned",
                        systemImage: "qrcode",
                        description: Text("Assign access to an existing rabbit, cage, or area, or create a new cage / area in the same flow.")
                    )
                }

                ForEach(store.smartAccess.sorted { $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending }) { access in
                    NavigationLink {
                        AccessDetailView(accessID: access.id)
                    } label: {
                        VStack(alignment: .leading, spacing: 4) {
                            Text(access.displayName).font(.headline)
                            Text("\(access.entityType) • QR + NFC")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                }
                .onDelete { offsets in
                    let ordered = store.smartAccess.sorted {
                        $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending
                    }
                    for offset in offsets {
                        store.removeSmartAccess(ordered[offset].id)
                    }
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("QR / NFC Management")
        .rabbitFlowNavigationChrome()
        .sheet(item: $assignmentAction) { action in
            NavigationStack {
                AccessAssignmentFlowView(action: action, showsCloseButton: true)
            }
        }
    }
}

struct AccessAssignmentFlowView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss

    let action: SmartAccessAction
    let showsCloseButton: Bool

    @StateObject private var nfc = RabbitNFCManager()
    @State private var targetMode = "Existing"
    @State private var existingSelection = ""
    @State private var newTargetType = "Cage / Hutch"
    @State private var newName = ""
    @State private var newLocation = ""
    @State private var resolvedTag: SmartAccessRecord?

    private var areas: [SmartAccessRecord] {
        store.smartAccess.filter { $0.entityType == "Area" }
    }

    var body: some View {
        Group {
            if let resolvedTag {
                resolvedView(resolvedTag)
            } else {
                Form {
                    Section("Assign To") {
                        Picker("Target", selection: $targetMode) {
                            Text("Existing Rabbit / Cage / Area").tag("Existing")
                            Text("Create New Cage / Area").tag("New")
                        }
                        .pickerStyle(.segmented)
                    }

                    if targetMode == "Existing" {
                        Section("Existing Rabbit / Cage / Area") {
                            Picker("Select", selection: $existingSelection) {
                                Text("Choose a rabbit, cage, or area").tag("")
                                ForEach(store.rabbits) { rabbit in
                                    Text("Rabbit: \(store.displayName(rabbit))")
                                        .tag("rabbit:\(rabbit.id.uuidString)")
                                }
                                ForEach(store.cages) { cage in
                                    Text("Cage: \(cage.name)")
                                        .tag("cage:\(cage.id.uuidString)")
                                }
                                ForEach(areas) { area in
                                    Text("Area: \(area.displayName)")
                                        .tag("area:\(area.id.uuidString)")
                                }
                            }
                        }
                    } else {
                        Section("Create New") {
                            Picker("Type", selection: $newTargetType) {
                                Text("Cage / Hutch").tag("Cage / Hutch")
                                Text("Area").tag("Area")
                            }
                            TextField(newTargetType == "Cage / Hutch" ? "Cage / hutch name" : "Area name", text: $newName)
                            TextField("Location / notes (optional)", text: $newLocation)
                        }
                    }

                    Section {
                        Button(targetMode == "Existing" ? "Continue" : "Create & Continue") {
                            resolveTarget()
                        }
                        .disabled(
                            targetMode == "Existing"
                                ? existingSelection.isEmpty
                                : newName.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
                        )
                    }
                }
                .rabbitFlowScrollableBackground()
            }
        }
        .navigationTitle(action.title)
        .navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar {
            if showsCloseButton {
                ToolbarItem(placement: .cancellationAction) {
                    Button("Close") { dismiss() }
                }
            }
        }
    }

    @ViewBuilder
    private func resolvedView(_ tag: SmartAccessRecord) -> some View {
        List {
            Section("Assigned To") {
                LabeledContent("Name", value: tag.displayName)
                LabeledContent("Type", value: tag.entityType)
                if !tag.entityName.isEmpty {
                    LabeledContent("Location", value: tag.entityName)
                }
            }

            if action == .assignQR {
                Section("QR Code") {
                    RabbitQRCodeView(text: tag.accessLink)
                        .frame(width: 240, height: 240)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)

                    if let shareURL = RabbitQRCodeUtilities.shareFileURL(text: tag.accessLink, title: tag.displayName) {
                        ShareLink(item: shareURL) {
                            Label("Share QR Code", systemImage: "square.and.arrow.up")
                        }
                    }

                    Button {
                        RabbitQRCodeUtilities.printQR(text: tag.accessLink, title: tag.displayName)
                    } label: {
                        Label("Print QR Code", systemImage: "printer.fill")
                    }

                    Text("The QR code is already generated and tied to this exact RabbitFlow record. No QR programming step is required.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            } else {
                Section("NFC Tag") {
                    Button {
                        nfc.beginWrite(code: tag.code)
                    } label: {
                        Label("Program NFC Tag Now", systemImage: "wave.3.right.circle.fill")
                            .font(.headline)
                    }
                    .disabled(!nfc.isAvailable || nfc.isRunning)

                    if nfc.isRunning {
                        HStack {
                            ProgressView()
                            Text("Hold the NFC tag near your iPhone…")
                        }
                    }

                    if let result = nfc.result {
                        Label("NFC tag programmed successfully.", systemImage: "checkmark.circle.fill")
                            .foregroundStyle(Color.rfForest)
                        Text(result).font(.caption.monospaced())
                    }

                    if let error = nfc.errorMessage {
                        Text(error).font(.caption).foregroundStyle(.red)
                    }

                    Text("This writes the same unique RabbitFlow link used by the QR code.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Section("Unique RabbitFlow Link") {
                Text(tag.accessLink)
                    .font(.caption.monospaced())
                    .textSelection(.enabled)
            }

            if showsCloseButton {
                Section {
                    Button("Done") { dismiss() }
                }
            }
        }
        .rabbitFlowScrollableBackground()
    }

    private func resolveTarget() {
        if targetMode == "Existing" {
            if existingSelection.hasPrefix("rabbit:"),
               let id = UUID(uuidString: String(existingSelection.dropFirst("rabbit:".count))),
               let rabbit = store.rabbits.first(where: { $0.id == id }) {
                resolvedTag = store.ensureSmartAccess(
                    label: store.displayName(rabbit),
                    entityType: "Rabbit",
                    entityID: rabbit.id,
                    entityName: rabbit.cageID.flatMap { cageID in store.cages.first(where: { $0.id == cageID })?.name } ?? rabbit.breed,
                    notes: "RabbitFlow smart access for rabbit record."
                )
                return
            }

            if existingSelection.hasPrefix("cage:"),
               let id = UUID(uuidString: String(existingSelection.dropFirst("cage:".count))),
               let cage = store.cages.first(where: { $0.id == id }) {
                resolvedTag = store.ensureSmartAccess(
                    label: cage.name,
                    entityType: "Cage / Hutch",
                    entityID: cage.id,
                    entityName: store.rabbitName(cage.rabbitID),
                    notes: "RabbitFlow smart access for cage / hutch."
                )
                return
            }

            if existingSelection.hasPrefix("area:"),
               let id = UUID(uuidString: String(existingSelection.dropFirst("area:".count))),
               let area = store.smartAccess.first(where: { $0.id == id }) {
                resolvedTag = area
                return
            }
        } else {
            let cleanName = newName.trimmingCharacters(in: .whitespacesAndNewlines)
            let cleanLocation = newLocation.trimmingCharacters(in: .whitespacesAndNewlines)

            if newTargetType == "Cage / Hutch" {
                let cage = CageRecord(
                    name: cleanName,
                    qrValue: "",
                    nfcValue: "",
                    rabbitID: nil,
                    notes: cleanLocation
                )
                store.cages.append(cage)
                resolvedTag = store.ensureSmartAccess(
                    label: cleanName,
                    entityType: "Cage / Hutch",
                    entityID: cage.id,
                    entityName: cleanLocation.isEmpty ? cleanName : cleanLocation,
                    notes: "Created while assigning RabbitFlow smart access."
                )
            } else {
                let area = store.ensureSmartAccess(
                    label: cleanName,
                    entityType: "Area",
                    entityID: nil,
                    entityName: cleanLocation.isEmpty ? cleanName : cleanLocation,
                    notes: "Rabbitry area with RabbitFlow smart access."
                )
                resolvedTag = area
            }
        }
    }
}

struct AccessLibraryView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let mode: AccessLibraryMode

    var body: some View {
        List {
            if store.smartAccess.isEmpty {
                ContentUnavailableView(
                    "No Assigned QR Codes",
                    systemImage: "qrcode",
                    description: Text("Generate or assign a QR code first.")
                )
            }

            ForEach(store.smartAccess.sorted { $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending }) { access in
                switch mode {
                case .viewQR:
                    NavigationLink {
                        AccessDetailView(accessID: access.id)
                    } label: {
                        accessRow(access)
                    }

                case .printQR:
                    Button {
                        RabbitQRCodeUtilities.printQR(text: access.accessLink, title: access.displayName)
                    } label: {
                        accessRow(access)
                    }

                case .shareQR:
                    if let url = RabbitQRCodeUtilities.shareFileURL(text: access.accessLink, title: access.displayName) {
                        ShareLink(item: url) { accessRow(access) }
                    } else {
                        accessRow(access)
                    }
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle(title)
        .rabbitFlowNavigationChrome()
    }

    private var title: String {
        switch mode {
        case .viewQR: return "View QR Code"
        case .printQR: return "Print QR"
        case .shareQR: return "Share QR"
        }
    }

    @ViewBuilder
    private func accessRow(_ access: SmartAccessRecord) -> some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text(access.displayName).font(.headline)
                Text(access.entityType)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
            Spacer()
            Image(systemName: mode == .printQR ? "printer" : (mode == .shareQR ? "square.and.arrow.up" : "qrcode"))
                .foregroundStyle(Color.rfForest)
        }
        .foregroundStyle(.primary)
    }
}

struct AccessDetailView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let accessID: UUID
    @StateObject private var nfc = RabbitNFCManager()
    @State private var showDeleteConfirmation = false

    private var access: SmartAccessRecord? {
        store.accessRecord(accessID)
    }

    var body: some View {
        List {
            if let access {
                Section("Assignment") {
                    LabeledContent("Name", value: access.displayName)
                    LabeledContent("Type", value: access.entityType)
                    if !access.entityName.isEmpty {
                        LabeledContent("Location", value: access.entityName)
                    }
                    if !access.notes.isEmpty {
                        LabeledContent("Notes", value: access.notes)
                    }
                }

                Section("Manage") {
                    NavigationLink {
                        EditSmartAccessView(accessID: access.id)
                    } label: {
                        Label("Edit Smart Access", systemImage: "pencil")
                    }

                    NavigationLink {
                        ReplaceReassignEditor(accessID: access.id)
                    } label: {
                        Label("Replace / Reassign", systemImage: "arrow.triangle.2.circlepath")
                    }

                    Button(role: .destructive) {
                        showDeleteConfirmation = true
                    } label: {
                        Label("Delete Smart Access", systemImage: "trash")
                    }
                }

                Section("QR Code") {
                    RabbitQRCodeView(text: access.accessLink)
                        .frame(width: 240, height: 240)
                        .frame(maxWidth: .infinity)
                        .padding(.vertical, 8)

                    if let url = RabbitQRCodeUtilities.shareFileURL(text: access.accessLink, title: access.displayName) {
                        ShareLink(item: url) {
                            Label("Share QR Code", systemImage: "square.and.arrow.up")
                        }
                    }

                    Button {
                        RabbitQRCodeUtilities.printQR(text: access.accessLink, title: access.displayName)
                    } label: {
                        Label("Print QR Code", systemImage: "printer.fill")
                    }
                }

                Section("NFC Tag") {
                    Button {
                        nfc.beginWrite(code: access.code)
                    } label: {
                        Label(
                            access.entityType == "Area"
                                ? "Program NFC Tag for This Area"
                                : "Program NFC Tag for This \(access.entityType)",
                            systemImage: "wave.3.right.circle.fill"
                        )
                    }
                    .disabled(!nfc.isAvailable || nfc.isRunning)

                    if nfc.isRunning {
                        HStack {
                            ProgressView()
                            Text("Hold the NFC tag near your iPhone…")
                        }
                    }
                    if let result = nfc.result {
                        Text(result)
                            .font(.caption)
                            .foregroundStyle(Color.rfForest)
                    }
                    if let error = nfc.errorMessage {
                        Text(error).font(.caption).foregroundStyle(.red)
                    }
                }

                Section("Unique RabbitFlow Link") {
                    Text(access.accessLink)
                        .font(.caption.monospaced())
                        .textSelection(.enabled)
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Smart Rabbit Access")
        .rabbitFlowNavigationChrome()
        .alert("Delete smart access?", isPresented: $showDeleteConfirmation) {
            Button("Delete", role: .destructive) {
                store.removeSmartAccess(accessID)
                dismiss()
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("This removes the QR/NFC assignment only. The rabbit, cage, or area record itself will not be deleted.")
        }
    }
}

struct EditSmartAccessView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let accessID: UUID

    @State private var label = ""
    @State private var location = ""
    @State private var notes = ""
    @State private var loaded = false

    var body: some View {
        Form {
            Section("Smart Access Details") {
                TextField("Access label", text: $label)
                TextField("Location / details", text: $location)
                TextField("Notes", text: $notes, axis: .vertical)
                    .lineLimit(3...6)
            }

            Section {
                Button("Save Changes") {
                    save()
                }
                .disabled(label.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Edit Smart Access")
        .rabbitFlowNavigationChrome()
        .onAppear {
            guard !loaded, let access = store.accessRecord(accessID) else { return }
            label = access.label
            location = access.entityName
            notes = access.notes
            loaded = true
        }
    }

    private func save() {
        guard var access = store.accessRecord(accessID) else { return }
        access.label = label.trimmingCharacters(in: .whitespacesAndNewlines)
        access.entityName = location.trimmingCharacters(in: .whitespacesAndNewlines)
        access.notes = notes.trimmingCharacters(in: .whitespacesAndNewlines)
        access.updatedAt = Date()
        store.updateSmartAccess(access)
        dismiss()
    }
}

struct ReplaceReassignView: View {
    @EnvironmentObject var store: RabbitFlowStore

    var body: some View {
        List {
            if store.smartAccess.isEmpty {
                ContentUnavailableView(
                    "Nothing to Replace or Reassign",
                    systemImage: "arrow.triangle.2.circlepath",
                    description: Text("Assign a QR code or NFC tag first.")
                )
            }

            ForEach(store.smartAccess.sorted { $0.displayName.localizedCaseInsensitiveCompare($1.displayName) == .orderedAscending }) { access in
                NavigationLink {
                    ReplaceReassignEditor(accessID: access.id)
                } label: {
                    VStack(alignment: .leading, spacing: 3) {
                        Text(access.displayName).font(.headline)
                        Text(access.entityType).font(.caption).foregroundStyle(.secondary)
                    }
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Replace / Reassign")
        .rabbitFlowNavigationChrome()
    }
}

struct ReplaceReassignEditor: View {
    @EnvironmentObject var store: RabbitFlowStore
    let accessID: UUID
    @State private var confirmReplace = false

    private var access: SmartAccessRecord? { store.accessRecord(accessID) }

    var body: some View {
        List {
            if let access {
                Section("Current Assignment") {
                    LabeledContent("Name", value: access.displayName)
                    LabeledContent("Type", value: access.entityType)
                    Text(access.accessLink)
                        .font(.caption.monospaced())
                        .textSelection(.enabled)
                }

                Section("Replace") {
                    Button(role: .destructive) {
                        confirmReplace = true
                    } label: {
                        Label("Replace QR / NFC Access Code", systemImage: "arrow.clockwise.circle")
                    }

                    Text("Replacing the access code makes previously printed QR codes and previously programmed NFC tags stop matching this setup. Print a new QR and reprogram the NFC tag afterward.")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }

                Section("Reassign") {
                    NavigationLink("Reassign to Existing Rabbit / Cage / Area") {
                        ReassignExistingTargetView(accessID: accessID)
                    }
                    NavigationLink("Reassign to New Cage / Area") {
                        ReassignNewTargetView(accessID: accessID)
                    }
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Replace / Reassign")
        .rabbitFlowNavigationChrome()
        .alert("Replace access code?", isPresented: $confirmReplace) {
            Button("Replace", role: .destructive) {
                guard var access else { return }
                access.code = UUID().uuidString
                access.updatedAt = Date()
                store.updateSmartAccess(access)
            }
            Button("Cancel", role: .cancel) {}
        } message: {
            Text("Old QR codes and NFC tags will no longer match this setup.")
        }
    }
}

struct ReassignExistingTargetView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let accessID: UUID

    private var areas: [SmartAccessRecord] {
        store.smartAccess.filter { $0.entityType == "Area" && $0.id != accessID }
    }

    var body: some View {
        List {
            Section("Rabbits") {
                ForEach(store.rabbits) { rabbit in
                    Button {
                        assign(
                            label: store.displayName(rabbit),
                            type: "Rabbit",
                            entityID: rabbit.id,
                            entityName: rabbit.breed
                        )
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(store.displayName(rabbit)).font(.headline)
                            Text("\(rabbit.breed) • \(rabbit.variety)")
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .foregroundStyle(.primary)
                }
            }

            Section("Cages / Hutches") {
                ForEach(store.cages) { cage in
                    Button {
                        assign(
                            label: cage.name,
                            type: "Cage / Hutch",
                            entityID: cage.id,
                            entityName: store.rabbitName(cage.rabbitID)
                        )
                    } label: {
                        VStack(alignment: .leading, spacing: 3) {
                            Text(cage.name).font(.headline)
                            Text(store.rabbitName(cage.rabbitID))
                                .font(.caption)
                                .foregroundStyle(.secondary)
                        }
                    }
                    .foregroundStyle(.primary)
                }
            }

            if !areas.isEmpty {
                Section("Areas") {
                    ForEach(areas) { area in
                        Button {
                            assign(
                                label: area.label,
                                type: "Area",
                                entityID: nil,
                                entityName: area.entityName
                            )
                            store.removeSmartAccess(area.id)
                        } label: {
                            Text(area.displayName).foregroundStyle(.primary)
                        }
                    }
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Choose Existing")
        .rabbitFlowNavigationChrome()
    }

    private func assign(label: String, type: String, entityID: UUID?, entityName: String) {
        guard var access = store.accessRecord(accessID) else { return }
        access.label = label
        access.entityType = type
        access.entityID = entityID
        access.entityName = entityName
        access.tagType = "QR + NFC"
        access.updatedAt = Date()
        store.updateSmartAccess(access)
        dismiss()
    }
}

struct ReassignNewTargetView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let accessID: UUID

    @State private var targetType = "Cage / Hutch"
    @State private var name = ""
    @State private var location = ""

    var body: some View {
        Form {
            Picker("Type", selection: $targetType) {
                Text("Cage / Hutch").tag("Cage / Hutch")
                Text("Area").tag("Area")
            }

            TextField(targetType == "Cage / Hutch" ? "Cage / hutch name" : "Area name", text: $name)
            TextField("Location / notes (optional)", text: $location)

            Button("Create & Reassign") {
                createAndAssign()
            }
            .disabled(name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Create New")
        .rabbitFlowNavigationChrome()
    }

    private func createAndAssign() {
        guard var access = store.accessRecord(accessID) else { return }
        let cleanName = name.trimmingCharacters(in: .whitespacesAndNewlines)
        let cleanLocation = location.trimmingCharacters(in: .whitespacesAndNewlines)

        if targetType == "Cage / Hutch" {
            let cage = CageRecord(
                name: cleanName,
                qrValue: "",
                nfcValue: "",
                rabbitID: nil,
                notes: cleanLocation
            )
            store.cages.append(cage)
            access.label = cleanName
            access.entityType = "Cage / Hutch"
            access.entityID = cage.id
            access.entityName = cleanLocation.isEmpty ? cleanName : cleanLocation
        } else {
            access.label = cleanName
            access.entityType = "Area"
            access.entityID = nil
            access.entityName = cleanLocation.isEmpty ? cleanName : cleanLocation
        }

        access.tagType = "QR + NFC"
        access.updatedAt = Date()
        store.updateSmartAccess(access)
        dismiss()
    }
}

struct ManualTagLookupView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var code = ""

    private var match: SmartAccessRecord? {
        let cleaned = code
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "rabbitflow://tag/", with: "")
        return store.smartAccess.first {
            $0.code.caseInsensitiveCompare(cleaned) == .orderedSame
        }
    }

    var body: some View {
        Form {
            TextField("Tag code", text: $code)
                .textInputAutocapitalization(.never)
                .autocorrectionDisabled()

            if let match {
                Section("Match") {
                    Text(match.displayName).font(.headline)
                    Text(match.entityType)
                    if !match.entityName.isEmpty { Text(match.entityName) }
                    NavigationLink("Open Smart Rabbit Access") {
                        AccessDetailView(accessID: match.id)
                    }
                }
            } else if !code.isEmpty {
                Text("No matching RabbitFlow tag.")
                    .foregroundStyle(.secondary)
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Tag Lookup")
        .rabbitFlowNavigationChrome()
    }
}

// MARK: - QR generation / print / share

enum RabbitQRCodeUtilities {
    private static let context = CIContext()

    static func image(for text: String) -> UIImage? {
        let filter = CIFilter.qrCodeGenerator()
        filter.message = Data(text.utf8)
        filter.correctionLevel = "H"

        guard let output = filter.outputImage?.transformed(by: CGAffineTransform(scaleX: 12, y: 12)),
              let cg = context.createCGImage(output, from: output.extent) else {
            return nil
        }

        return brandedImage(from: UIImage(cgImage: cg))
    }

    private static func brandedImage(from qrImage: UIImage) -> UIImage {
        guard let logo = UIImage(named: "RabbitFlowBrandMark") else { return qrImage }

        let size = qrImage.size
        let minimumSide = min(size.width, size.height)
        let whitePlateSide = floor(minimumSide * 0.21)
        let logoSide = floor(minimumSide * 0.16)

        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        format.opaque = true

        return UIGraphicsImageRenderer(size: size, format: format).image { renderer in
            let fullRect = CGRect(origin: .zero, size: size)
            UIColor.white.setFill()
            renderer.fill(fullRect)
            qrImage.draw(in: fullRect)

            let plateRect = CGRect(
                x: floor((size.width - whitePlateSide) / 2),
                y: floor((size.height - whitePlateSide) / 2),
                width: whitePlateSide,
                height: whitePlateSide
            )
            let platePath = UIBezierPath(
                roundedRect: plateRect,
                cornerRadius: whitePlateSide * 0.16
            )
            UIColor.white.setFill()
            platePath.fill()

            let logoRect = CGRect(
                x: floor((size.width - logoSide) / 2),
                y: floor((size.height - logoSide) / 2),
                width: logoSide,
                height: logoSide
            )

            renderer.cgContext.saveGState()
            UIBezierPath(
                roundedRect: logoRect,
                cornerRadius: logoSide * 0.18
            ).addClip()
            logo.draw(in: logoRect)
            renderer.cgContext.restoreGState()
        }
    }

    static func shareFileURL(text: String, title: String) -> URL? {
        guard let image = image(for: text),
              let data = image.pngData() else { return nil }

        let safeName = title
            .replacingOccurrences(of: "/", with: "-")
            .replacingOccurrences(of: ":", with: "-")
        let url = FileManager.default.temporaryDirectory
            .appendingPathComponent("\(safeName)-RabbitFlow-QR.png")

        do {
            try data.write(to: url, options: .atomic)
            return url
        } catch {
            return nil
        }
    }

    @MainActor
    static func printQR(text: String, title: String) {
        guard let image = image(for: text) else { return }

        let controller = UIPrintInteractionController.shared
        let info = UIPrintInfo(dictionary: nil)
        info.outputType = .photo
        info.jobName = "\(title) - RabbitFlow QR"
        controller.printInfo = info
        controller.printingItem = image

        if UIDevice.current.userInterfaceIdiom == .pad,
           let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first,
           let sourceView = scene.windows.first(where: { $0.isKeyWindow })?.rootViewController?.view {
            let sourceRect = CGRect(
                x: sourceView.bounds.midX,
                y: sourceView.bounds.midY,
                width: 1,
                height: 1
            )
            controller.present(from: sourceRect, in: sourceView, animated: true, completionHandler: nil)
        } else {
            controller.present(animated: true, completionHandler: nil)
        }
    }
}

struct RabbitQRCodeView: View {
    let text: String

    var body: some View {
        if let image = RabbitQRCodeUtilities.image(for: text) {
            Image(uiImage: image)
                .interpolation(.none)
                .resizable()
                .scaledToFit()
        } else {
            Image(systemName: "qrcode")
                .resizable()
                .scaledToFit()
        }
    }
}

// MARK: - Camera QR scanner

struct QRScannerView: UIViewControllerRepresentable {
    let onCode: (String) -> Void

    func makeUIViewController(context: Context) -> ScannerController {
        let viewController = ScannerController()
        viewController.onCode = onCode
        return viewController
    }

    func updateUIViewController(
        _ uiViewController: ScannerController,
        context: Context
    ) {}
}

final class ScannerController: UIViewController, AVCaptureMetadataOutputObjectsDelegate {
    var onCode: ((String) -> Void)?
    private let session = AVCaptureSession()
    private var preview: AVCaptureVideoPreviewLayer?

    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .black

        guard let device = AVCaptureDevice.default(for: .video),
              let input = try? AVCaptureDeviceInput(device: device),
              session.canAddInput(input) else {
            return
        }

        session.addInput(input)

        let output = AVCaptureMetadataOutput()
        guard session.canAddOutput(output) else { return }

        session.addOutput(output)
        output.setMetadataObjectsDelegate(self, queue: .main)
        output.metadataObjectTypes = [.qr]

        let preview = AVCaptureVideoPreviewLayer(session: session)
        preview.videoGravity = .resizeAspectFill
        preview.frame = view.bounds
        view.layer.addSublayer(preview)
        self.preview = preview

        DispatchQueue.global(qos: .userInitiated).async {
            self.session.startRunning()
        }
    }

    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        preview?.frame = view.bounds
    }

    func metadataOutput(
        _ output: AVCaptureMetadataOutput,
        didOutput metadataObjects: [AVMetadataObject],
        from connection: AVCaptureConnection
    ) {
        guard let code = (metadataObjects.first as? AVMetadataMachineReadableCodeObject)?.stringValue else {
            return
        }

        session.stopRunning()
        onCode?(code)
    }
}
