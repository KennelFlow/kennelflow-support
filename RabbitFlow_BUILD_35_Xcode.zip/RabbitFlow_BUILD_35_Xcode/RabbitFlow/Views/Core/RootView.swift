import SwiftUI

struct RootView: View {
    @State private var selection = 0
    @State private var showScanner = false

    var body: some View {
        TabView(selection: $selection) {
                NavigationStack { HomeView(showScanner: $showScanner, tabSelection: $selection) }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(0)

                NavigationStack { RabbitsView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(1)

                NavigationStack { BreedingView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(2)

                NavigationStack { LittersView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(3)

                NavigationStack { MoreView() }
                    .toolbar(.hidden, for: .tabBar)
                    .tag(4)
        }
        .safeAreaInset(edge: .bottom, spacing: 0) {
            RabbitFlowTabBar(selection: $selection)
                .padding(.horizontal, 18)
                .padding(.top, 4)
                .padding(.bottom, 7)
                .background(Color.clear)
        }
        .sheet(isPresented: $showScanner) {
            NavigationStack { ScannerHubView() }
                .tint(Color.rfForest)
        }
    }
}

private struct RabbitFlowTabBar: View {
    @Binding var selection: Int

    private let items: [(String, String)] = [
        ("Home", "house.fill"),
        ("Rabbits", "hare.fill"),
        ("Breeding", "heart.fill"),
        ("Litters", "pawprint.fill"),
        ("More", "ellipsis")
    ]

    var body: some View {
        HStack(spacing: 4) {
            ForEach(Array(items.enumerated()), id: \.offset) { index, item in
                Button {
                    withAnimation(.easeInOut(duration: 0.16)) { selection = index }
                } label: {
                    VStack(spacing: 5) {
                        Image(systemName: item.1)
                            .font(.system(size: 22, weight: .semibold))
                        Text(item.0)
                            .font(.system(size: 12, weight: .semibold))
                    }
                    .foregroundStyle(selection == index ? Color.rfGold : Color.black.opacity(0.83))
                    .frame(maxWidth: .infinity)
                    .frame(height: 66)
                    .background(
                        RoundedRectangle(cornerRadius: 28, style: .continuous)
                            .fill(selection == index ? Color.rfWarmCream.opacity(0.95) : Color.clear)
                    )
                }
                .buttonStyle(.plain)
            }
        }
        .padding(5)
        .background(Color.rfCream.opacity(0.99), in: Capsule())
        .overlay(Capsule().stroke(Color.white.opacity(0.75), lineWidth: 1))
        .shadow(color: .black.opacity(0.18), radius: 10, y: 4)
    }
}
