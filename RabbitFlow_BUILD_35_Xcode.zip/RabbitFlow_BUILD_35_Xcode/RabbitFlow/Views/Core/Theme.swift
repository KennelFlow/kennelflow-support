import SwiftUI

extension Color {
    static let rfDeepGreen = Color(red: 0.025, green: 0.22, blue: 0.12)
    static let rfForest = Color(red: 0.045, green: 0.31, blue: 0.16)
    static let rfCream = Color(red: 0.965, green: 0.95, blue: 0.89)
    static let rfWarmCream = Color(red: 0.93, green: 0.91, blue: 0.84)
    static let rfGold = Color(red: 0.88, green: 0.78, blue: 0.48)
}

struct FlowCard<Content: View>: View {
    let content: Content
    init(@ViewBuilder content: () -> Content) { self.content = content() }

    var body: some View {
        content
            .padding(14)
            .frame(maxWidth: .infinity, alignment: .leading)
            .background(Color.rfCream.opacity(0.97), in: RoundedRectangle(cornerRadius: 16, style: .continuous))
            .overlay(
                RoundedRectangle(cornerRadius: 16, style: .continuous)
                    .stroke(Color.white.opacity(0.45), lineWidth: 1)
            )
            .shadow(color: .black.opacity(0.13), radius: 7, x: 0, y: 3)
    }
}

struct RabbitFlowBackground: View {
    var body: some View {
        LinearGradient(
            colors: [Color.rfForest, Color.rfDeepGreen],
            startPoint: .top,
            endPoint: .bottom
        )
        .ignoresSafeArea()
    }
}

struct RabbitFlowSectionHeader: View {
    let title: String
    let icon: String

    var body: some View {
        HStack(spacing: 9) {
            Image(systemName: icon)
                .font(.headline)
            Text(title)
                .font(.headline.weight(.bold))
            Spacer()
        }
        .foregroundStyle(Color.rfDeepGreen)
    }
}

struct EmptyState: View {
    let icon: String
    let title: String
    let message: String

    var body: some View {
        ZStack {
            RabbitFlowBackground()
            VStack(spacing: 14) {
                Image(systemName: icon)
                    .font(.system(size: 46, weight: .semibold))
                    .foregroundStyle(Color.rfGold)
                Text(title)
                    .font(.title2.bold())
                    .foregroundStyle(.white)
                Text(message)
                    .font(.subheadline)
                    .foregroundStyle(.white.opacity(0.82))
                    .multilineTextAlignment(.center)
                    .padding(.horizontal, 30)
            }
        }
    }
}

extension View {
    func rabbitFlowNavigationChrome() -> some View {
        self
            .tint(Color.rfForest)
            .toolbarBackground(Color.rfDeepGreen, for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbarColorScheme(.dark, for: .navigationBar)
    }

    func rabbitFlowScrollableBackground() -> some View {
        self
            .scrollContentBackground(.hidden)
            .background(Color.rfWarmCream)
    }
}
