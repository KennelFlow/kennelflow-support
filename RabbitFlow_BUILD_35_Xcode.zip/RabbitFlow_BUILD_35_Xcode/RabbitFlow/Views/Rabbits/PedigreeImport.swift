import SwiftUI
import UIKit
import VisionKit
import Vision
import PDFKit
import UniformTypeIdentifiers

struct PedigreeImportButtons: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbitID: UUID
    @State private var showScanner = false
    @State private var showImporter = false
    @State private var working = false
    @State private var message: String?

    var body: some View {
        VStack(spacing: 10) {
            Button { showScanner = true } label: {
                Label("Scan Pedigree", systemImage: "doc.viewfinder").frame(maxWidth: .infinity).padding(.vertical, 11)
            }.buttonStyle(.borderedProminent).tint(Color.rfForest)

            Button { showImporter = true } label: {
                Label("Upload Pedigree", systemImage: "square.and.arrow.up").frame(maxWidth: .infinity).padding(.vertical, 11)
            }.buttonStyle(.bordered).tint(Color.rfForest)

            if working { ProgressView("Reading pedigree…") }
            if let message { Text(message).font(.caption).foregroundStyle(.secondary) }
        }
        .sheet(isPresented: $showScanner) {
            DocumentScanner { images in
                showScanner = false
                guard !images.isEmpty else { return }
                Task { await importImages(images) }
            }
        }
        .fileImporter(isPresented: $showImporter, allowedContentTypes: [.pdf, .png, .jpeg], allowsMultipleSelection: false) { result in
            guard case .success(let urls) = result, let url = urls.first else { return }
            Task { await importURL(url) }
        }
    }

    @MainActor private func finish(data: Data, fileName: String, text: String) {
        let parsed = PedigreeTextParser.parse(text)
        store.savePedigreeDocument(PedigreeDocument(rabbitID: rabbitID, fileName: fileName, data: data, extractedText: text))
        store.applyParsedPedigree(lineage: parsed.lineage, to: rabbitID)
        working = false
        if !parsed.lineage.isEmpty {
            message = "Pedigree saved and recognized parent names were added to the RabbitFlow system pedigree."
        } else {
            message = "Pedigree saved to this rabbit. If the document layout could not be read automatically, the original pedigree remains attached for review."
        }
    }

    @MainActor private func importImages(_ images: [UIImage]) async {
        working = true
        message = nil
        let text = await PedigreeOCR.recognize(images: images)
        let data = images.first?.jpegData(compressionQuality: 0.9) ?? Data()
        finish(data: data, fileName: "Scanned_Pedigree.jpg", text: text)
    }

    @MainActor private func importURL(_ url: URL) async {
        working = true
        message = nil
        let access = url.startAccessingSecurityScopedResource(); defer { if access { url.stopAccessingSecurityScopedResource() } }
        guard let data = try? Data(contentsOf: url) else { working = false; message = "Could not open that file."; return }
        var images: [UIImage] = []
        if url.pathExtension.lowercased() == "pdf", let pdf = PDFDocument(data: data) {
            for i in 0..<min(pdf.pageCount, 4) { if let page = pdf.page(at: i) { images.append(page.thumbnail(of: CGSize(width: 1800, height: 2400), for: .mediaBox)) } }
        } else if let image = UIImage(data: data) { images = [image] }
        let text = await PedigreeOCR.recognize(images: images)
        finish(data: data, fileName: url.lastPathComponent, text: text)
    }
}

private struct DocumentScanner: UIViewControllerRepresentable {
    let completion: ([UIImage]) -> Void
    func makeCoordinator() -> Coordinator { Coordinator(completion: completion) }
    func makeUIViewController(context: Context) -> VNDocumentCameraViewController { let vc = VNDocumentCameraViewController(); vc.delegate = context.coordinator; return vc }
    func updateUIViewController(_ uiViewController: VNDocumentCameraViewController, context: Context) {}
    final class Coordinator: NSObject, VNDocumentCameraViewControllerDelegate {
        let completion: ([UIImage]) -> Void
        init(completion: @escaping ([UIImage]) -> Void) { self.completion = completion }
        func documentCameraViewController(_ controller: VNDocumentCameraViewController, didFinishWith scan: VNDocumentCameraScan) { completion((0..<scan.pageCount).map { scan.imageOfPage(at: $0) }) }
        func documentCameraViewControllerDidCancel(_ controller: VNDocumentCameraViewController) { completion([]) }
    }
}

enum PedigreeOCR {
    static func recognize(images: [UIImage]) async -> String {
        await withTaskGroup(of: String.self) { group in
            for image in images { group.addTask { recognize(image: image) } }
            var parts: [String] = []; for await value in group { parts.append(value) }; return parts.joined(separator: "\n")
        }
    }
    private static func recognize(image: UIImage) -> String {
        guard let cg = image.cgImage else { return "" }
        let request = VNRecognizeTextRequest(); request.recognitionLevel = .accurate; request.usesLanguageCorrection = true
        try? VNImageRequestHandler(cgImage: cg).perform([request])
        return (request.results ?? []).compactMap { $0.topCandidates(1).first?.string }.joined(separator: "\n")
    }
}

enum PedigreeTextParser {
    static func parse(_ text: String) -> (sire: String?, dam: String?, lineage: [String: String]) {
        let lines = text.components(separatedBy: .newlines)
            .map { $0.trimmingCharacters(in: .whitespacesAndNewlines) }
            .filter { !$0.isEmpty }

        var labels: [(path: String, names: [String])] = []
        for depth in stride(from: 5, through: 1, by: -1) {
            for path in pedigreePathKeys(depth: depth) {
                let words = path.map { $0 == "s" ? "sire" : "dam" }
                let apostrophe = words.dropLast().map { "\($0)'s" }.joined(separator: " ")
                let final = words.last ?? ""
                let longLabel = ([apostrophe, final].filter { !$0.isEmpty }).joined(separator: " ")
                let spaced = words.joined(separator: " ")
                labels.append((path, [longLabel, spaced]))
            }
        }

        // Common pedigree wording aliases.
        labels.append(contentsOf: [
            (path: "ss", names: ["paternal grandsire"]),
            (path: "sd", names: ["paternal granddam"]),
            (path: "ds", names: ["maternal grandsire"]),
            (path: "dd", names: ["maternal granddam"]),
            (path: "s", names: ["father"]),
            (path: "d", names: ["mother"])
        ])

        var lineage: [String: String] = [:]
        for (index, line) in lines.enumerated() {
            let lower = normalize(line)
            for item in labels where lineage[item.path] == nil {
                guard let matched = item.names.first(where: { lower == $0 || lower.hasPrefix($0 + ":") || lower.hasPrefix($0 + " ") }) else { continue }
                let value = extractValue(from: line, normalizedLabel: matched, nextLine: index + 1 < lines.count ? lines[index + 1] : nil)
                if let value, !value.isEmpty, !looksLikeLabel(value) { lineage[item.path] = value }
            }
        }
        return (lineage["s"], lineage["d"], lineage)
    }

    private static func pedigreePathKeys(depth: Int) -> [String] {
        guard depth > 0 else { return [""] }
        return pedigreePathKeys(depth: depth - 1).flatMap { [$0 + "s", $0 + "d"] }
    }

    private static func normalize(_ value: String) -> String {
        value.lowercased()
            .replacingOccurrences(of: "’", with: "'")
            .replacingOccurrences(of: "  ", with: " ")
            .trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func extractValue(from line: String, normalizedLabel: String, nextLine: String?) -> String? {
        if let colon = line.firstIndex(of: ":") {
            let after = String(line[line.index(after: colon)...]).trimmingCharacters(in: .whitespacesAndNewlines)
            if !after.isEmpty { return after }
        }
        let normalizedLine = normalize(line)
        if normalizedLine.hasPrefix(normalizedLabel), normalizedLine.count > normalizedLabel.count {
            let offset = line.index(line.startIndex, offsetBy: min(normalizedLabel.count, line.count))
            let after = String(line[offset...]).trimmingCharacters(in: CharacterSet(charactersIn: " -–—:\t"))
            if !after.isEmpty { return after }
        }
        return nextLine?.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private static func looksLikeLabel(_ value: String) -> Bool {
        let lower = normalize(value)
        return ["sire", "dam", "father", "mother", "breed", "color", "sex", "dob", "registration", "reg #"].contains(where: { lower == $0 || lower.hasPrefix($0 + ":") })
    }
}

