import SwiftUI
import UIKit
import PhotosUI

struct RabbitsView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @State private var showAdd = false

    var body: some View {
        Group {
            if store.rabbits.isEmpty {
                EmptyState(icon: "hare", title: "No Rabbits Yet", message: "Add your first rabbit to begin your RabbitFlow records.")
            } else {
                List {
                    ForEach(store.rabbits) { rabbit in
                        NavigationLink {
                            RabbitProfileView(rabbitID: rabbit.id)
                        } label: {
                            HStack(spacing: 12) {
                                RabbitThumbnail(rabbit: rabbit, size: 46)
                                VStack(alignment: .leading, spacing: 3) {
                                    Text(store.displayName(rabbit)).font(.headline)
                                    Text([rabbit.breed, rabbit.variety, rabbit.tattooID].filter { !$0.isEmpty }.joined(separator: " • "))
                                        .font(.caption)
                                        .foregroundStyle(.secondary)
                                }
                                Spacer()
                                Text(rabbit.status.rawValue)
                                    .font(.caption.weight(.semibold))
                                    .foregroundStyle(Color.rfForest)
                            }
                            .padding(.vertical, 3)
                        }
                    }
                    .onDelete { offsets in
                        store.rabbits.remove(atOffsets: offsets)
                    }
                }
                .rabbitFlowScrollableBackground()
            }
        }
        .navigationTitle("Rabbits")
        .rabbitFlowNavigationChrome()
        .toolbar {
            ToolbarItem(placement: .topBarTrailing) {
                Button { showAdd = true } label: { Image(systemName: "plus") }
            }
        }
        .sheet(isPresented: $showAdd) {
            NavigationStack { RabbitForm(rabbit: nil) }
                .environmentObject(store)
        }
    }
}

struct RabbitProfileView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbitID: UUID
    @State private var showEdit = false

    private var rabbit: Rabbit? { store.rabbit(rabbitID) }

    var body: some View {
        Group {
            if let rabbit {
                ScrollView {
                    VStack(spacing: 14) {
                        FlowCard {
                            HStack(alignment: .top, spacing: 14) {
                                RabbitThumbnail(rabbit: rabbit, size: 108, cornerRadius: 18)

                                VStack(alignment: .leading, spacing: 5) {
                                    Text(store.displayName(rabbit))
                                        .font(.title2.bold())
                                    Text(rabbit.breed)
                                        .font(.headline)
                                    Text(rabbit.variety)
                                        .font(.subheadline)
                                        .foregroundStyle(.secondary)
                                    Label(rabbit.sex.rawValue, systemImage: rabbit.sex == .buck ? "arrow.up.circle.fill" : "arrow.down.circle.fill")
                                        .font(.caption.weight(.semibold))
                                        .foregroundStyle(Color.rfForest)
                                }
                                Spacer()
                            }
                        }

                        HStack(spacing: 9) {
                            ProfileAction(title: "Pedigree", icon: "point.3.connected.trianglepath.dotted") {
                                AnyView(PedigreeView(rabbitID: rabbit.id))
                            }
                            ProfileAction(title: "Breeding", icon: "heart.fill") {
                                AnyView(BreedingHistoryView(rabbitID: rabbit.id))
                            }
                            ProfileAction(title: "Details", icon: "doc.text.fill") {
                                AnyView(RabbitDetailsView(rabbitID: rabbit.id))
                            }
                        }

                        FlowCard {
                            RabbitFlowSectionHeader(title: "Rabbit Information", icon: "list.bullet.rectangle")
                            Divider().padding(.vertical, 5)
                            detailRow("Tattoo / ID", rabbit.tattooID)
                            detailRow("DOB", rabbit.dateOfBirth.formatted(date: .abbreviated, time: .omitted))
                            detailRow("Weight", rabbit.weight > 0 ? "\(rabbit.weight.formatted(.number.precision(.fractionLength(0...2)))) lb" : "Not entered")
                            detailRow("Registration", rabbit.registrationNumber.isEmpty ? "Not entered" : rabbit.registrationNumber)
                            detailRow("Status", rabbit.status.rawValue)
                            detailRow("Breeder / Source", rabbit.breederSource.isEmpty ? "Not entered" : rabbit.breederSource)
                        }

                        if !rabbit.notes.isEmpty {
                            FlowCard {
                                RabbitFlowSectionHeader(title: "Notes", icon: "note.text")
                                Text(rabbit.notes)
                                    .font(.subheadline)
                                    .foregroundStyle(.secondary)
                                    .padding(.top, 4)
                            }
                        }
                    }
                    .padding(12)
                    // Reserve enough space so the fixed pedigree control never sits
                    // underneath RabbitFlow's custom bottom navigation.
                    .padding(.bottom, 118)
                }
                .overlay(alignment: .bottom) {
                    NavigationLink {
                        PedigreeView(rabbitID: rabbit.id)
                    } label: {
                        HStack(spacing: 12) {
                            Image(systemName: "point.3.connected.trianglepath.dotted")
                            Text("VIEW FULL PEDIGREE")
                                .fontWeight(.heavy)
                            Spacer()
                            Image(systemName: "chevron.right")
                        }
                        .font(.headline)
                        .foregroundStyle(.white)
                        .padding(.horizontal, 20)
                        .frame(maxWidth: .infinity)
                        .frame(height: 60)
                        .background(
                            LinearGradient(colors: [Color.rfForest, Color.rfDeepGreen], startPoint: .leading, endPoint: .trailing),
                            in: RoundedRectangle(cornerRadius: 18, style: .continuous)
                        )
                        .shadow(color: .black.opacity(0.22), radius: 8, y: 3)
                        .contentShape(RoundedRectangle(cornerRadius: 18, style: .continuous))
                    }
                    .buttonStyle(.plain)
                    .accessibilityLabel("View Full Pedigree")
                    .padding(.horizontal, 14)
                    // RabbitFlowTabBar is ~82pt tall. Keep this control clearly above it.
                    .padding(.bottom, 92)
                }
                .background(Color.rfWarmCream)
                .navigationTitle(store.displayName(rabbit))
                .navigationBarTitleDisplayMode(.inline)
                .rabbitFlowNavigationChrome()
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button("Edit") { showEdit = true }
                    }
                }
                .sheet(isPresented: $showEdit) {
                    NavigationStack { RabbitForm(rabbit: store.rabbit(rabbitID)) }
                        .environmentObject(store)
                }
            } else {
                ContentUnavailableView("Rabbit Not Found", systemImage: "hare", description: Text("This rabbit record is no longer available."))
            }
        }
    }

    @ViewBuilder
    private func detailRow(_ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline) {
            Text(label).foregroundStyle(.secondary)
            Spacer()
            Text(value).multilineTextAlignment(.trailing)
        }
        .font(.subheadline)
        .padding(.vertical, 3)
    }
}

private struct RabbitThumbnail: View {
    let rabbit: Rabbit
    let size: CGFloat
    var cornerRadius: CGFloat = 12

    var body: some View {
        Group {
            if let data = rabbit.photoData, let image = UIImage(data: data) {
                Image(uiImage: image)
                    .resizable()
                    .scaledToFill()
            } else {
                ZStack {
                    Color.rfWarmCream
                    Image(systemName: "hare.fill")
                        .font(.system(size: size * 0.45, weight: .semibold))
                        .foregroundStyle(Color.rfForest)
                }
            }
        }
        .frame(width: size, height: size)
        .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous).stroke(Color.rfForest.opacity(0.14), lineWidth: 1))
    }
}

private struct ProfileAction: View {
    let title: String
    let icon: String
    let destination: () -> AnyView

    var body: some View {
        NavigationLink {
            destination()
        } label: {
            VStack(spacing: 6) {
                Image(systemName: icon).font(.headline)
                Text(title).font(.caption.weight(.semibold))
            }
            .frame(maxWidth: .infinity)
            .frame(height: 68)
            .foregroundStyle(Color.rfDeepGreen)
            .background(Color.rfCream, in: RoundedRectangle(cornerRadius: 13))
            .overlay(RoundedRectangle(cornerRadius: 13).stroke(Color.rfForest.opacity(0.15)))
        }
        .buttonStyle(.plain)
    }
}

struct RabbitDetailsView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbitID: UUID

    var body: some View {
        List {
            if let rabbit = store.rabbit(rabbitID) {
                Section("Identity") {
                    LabeledContent("Name", value: store.displayName(rabbit))
                    LabeledContent("Tattoo / ID", value: rabbit.tattooID.isEmpty ? "Not entered" : rabbit.tattooID)
                    LabeledContent("Sex", value: rabbit.sex.rawValue)
                    LabeledContent("Date of Birth", value: rabbit.dateOfBirth.formatted(date: .abbreviated, time: .omitted))
                }
                Section("Breed") {
                    LabeledContent("Breed", value: rabbit.breed)
                    LabeledContent("Variety / Color", value: rabbit.variety)
                    LabeledContent("Weight", value: rabbit.weight > 0 ? "\(rabbit.weight) lb" : "Not entered")
                }
                Section("Records") {
                    LabeledContent("Registration", value: rabbit.registrationNumber.isEmpty ? "Not entered" : rabbit.registrationNumber)
                    LabeledContent("Status", value: rabbit.status.rawValue)
                    LabeledContent("Breeder / Source", value: rabbit.breederSource.isEmpty ? "Not entered" : rabbit.breederSource)
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Rabbit Details")
        .navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
    }
}

struct BreedingHistoryView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbitID: UUID

    var records: [BreedingRecord] {
        store.breedings.filter { $0.doeID == rabbitID || $0.buckID == rabbitID }
    }

    var body: some View {
        List {
            if records.isEmpty {
                ContentUnavailableView("No Breeding History", systemImage: "heart", description: Text("Breeding records for this rabbit will appear here."))
            } else {
                ForEach(records.sorted(by: { $0.breedingDate > $1.breedingDate })) { record in
                    VStack(alignment: .leading, spacing: 4) {
                        Text(record.breedingDate.formatted(date: .abbreviated, time: .omitted)).font(.headline)
                        Text("Doe: \(store.rabbitName(record.doeID)) • Buck: \(store.rabbitName(record.buckID))")
                            .font(.caption)
                            .foregroundStyle(.secondary)
                    }
                }
            }
        }
        .rabbitFlowScrollableBackground()
        .navigationTitle("Breeding History")
        .navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
    }
}

struct RabbitForm: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let rabbit: Rabbit?

    @State private var name = ""
    @State private var tattooID = ""
    @State private var sex: RabbitSex = .doe
    @State private var dob = Date()
    @State private var breed = "New Zealand"
    @State private var variety = "White"
    @State private var weight = 0.0
    @State private var status: RabbitStatus = .active
    @State private var registration = ""
    @State private var source = ""
    @State private var purchasePrice = 0.0
    @State private var notes = ""
    @State private var sireID: UUID?
    @State private var damID: UUID?
    @State private var draftID = UUID()
    @State private var photoData: Data?
    @State private var selectedPhoto: PhotosPickerItem?

    var body: some View {
        Form {
            Section("Photo") {
                HStack(spacing: 14) {
                    if let photoData, let image = UIImage(data: photoData) {
                        Image(uiImage: image)
                            .resizable()
                            .scaledToFill()
                            .frame(width: 112, height: 112)
                            .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    } else {
                        ZStack {
                            RoundedRectangle(cornerRadius: 16, style: .continuous)
                                .fill(Color.rfWarmCream)
                            Image(systemName: "hare.fill")
                                .font(.system(size: 46, weight: .semibold))
                                .foregroundStyle(Color.rfForest)
                        }
                        .frame(width: 112, height: 112)
                    }

                    VStack(alignment: .leading, spacing: 10) {
                        PhotosPicker(selection: $selectedPhoto, matching: .images) {
                            Label(photoData == nil ? "Add Rabbit Photo" : "Change Photo", systemImage: "photo")
                        }
                        .buttonStyle(.borderedProminent)
                        .tint(Color.rfForest)

                        if photoData != nil {
                            Button(role: .destructive) { photoData = nil } label: {
                                Label("Remove Photo", systemImage: "trash")
                            }
                        }
                    }
                }
                .onChange(of: selectedPhoto) { _, item in
                    guard let item else { return }
                    Task {
                        if let data = try? await item.loadTransferable(type: Data.self) {
                            await MainActor.run { photoData = data }
                        }
                    }
                }
            }

            Section("Identity") {
                TextField("Name", text: $name)
                TextField("Tattoo / ID", text: $tattooID)
                Picker("Sex", selection: $sex) { ForEach(RabbitSex.allCases) { Text($0.rawValue).tag($0) } }
                DatePicker("Date of Birth", selection: $dob, displayedComponents: .date)
            }

            Section("Breed & Variety") {
                Picker("Breed", selection: $breed) {
                    ForEach(BreedCatalog.breeds.keys.sorted(), id: \.self) { Text($0).tag($0) }
                }
                .onChange(of: breed) { _, newValue in
                    variety = BreedCatalog.breeds[newValue]?.first ?? ""
                }

                Picker("Variety / Color", selection: $variety) {
                    ForEach(BreedCatalog.breeds[breed] ?? [], id: \.self) { Text($0).tag($0) }
                }
            }

            Section("Pedigree Document") {
                PedigreeImportButtons(rabbitID: rabbit?.id ?? draftID)
                    .environmentObject(store)
                if let doc = store.pedigreeDocument(for: rabbit?.id ?? draftID) {
                    Label(doc.fileName, systemImage: "doc.richtext")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                }
            }

            Section("Pedigree Parents") {
                Picker("Sire", selection: $sireID) {
                    Text("Not entered").tag(UUID?.none)
                    ForEach(store.rabbits.filter { candidate in
                        candidate.sex == .buck && candidate.id != (rabbit?.id ?? draftID)
                    }) { candidate in
                        Text(store.displayName(candidate)).tag(Optional(candidate.id))
                    }
                }

                Picker("Dam", selection: $damID) {
                    Text("Not entered").tag(UUID?.none)
                    ForEach(store.rabbits.filter { candidate in
                        candidate.sex == .doe && candidate.id != (rabbit?.id ?? draftID)
                    }) { candidate in
                        Text(store.displayName(candidate)).tag(Optional(candidate.id))
                    }
                }

                Text("Choose the sire and dam here. Their parents are followed automatically to build the full 5-generation pedigree.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Section("Details") {
                TextField("Weight (lb)", value: $weight, format: .number).keyboardType(.decimalPad)
                Picker("Status", selection: $status) { ForEach(RabbitStatus.allCases) { Text($0.rawValue).tag($0) } }
                TextField("Registration Number", text: $registration)
                TextField("Breeder / Source", text: $source)
                TextField("Purchase Price", value: $purchasePrice, format: .currency(code: "USD")).keyboardType(.decimalPad)
                TextField("Notes", text: $notes, axis: .vertical)
            }
        }
        .navigationTitle(rabbit == nil ? "Add Rabbit" : "Edit Rabbit")
        .navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar {
            ToolbarItem(placement: .cancellationAction) { Button("Cancel") { dismiss() } }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { save() }
                    .disabled(name.trimmingCharacters(in: .whitespaces).isEmpty && tattooID.trimmingCharacters(in: .whitespaces).isEmpty)
            }
        }
        .onAppear {
            guard let r = rabbit else { return }
            name = r.name
            tattooID = r.tattooID
            sex = r.sex
            dob = r.dateOfBirth
            breed = r.breed
            variety = r.variety
            weight = r.weight
            status = r.status
            registration = r.registrationNumber
            source = r.breederSource
            purchasePrice = r.purchasePrice
            notes = r.notes
            sireID = r.sireID
            damID = r.damID
            photoData = r.photoData
        }
    }

    private func save() {
        let updated = Rabbit(
            id: rabbit?.id ?? draftID,
            name: name,
            tattooID: tattooID,
            sex: sex,
            dateOfBirth: dob,
            breed: breed,
            variety: variety,
            weight: weight,
            status: status,
            registrationNumber: registration,
            breederSource: source,
            purchasePrice: purchasePrice,
            cageID: rabbit?.cageID,
            sireID: sireID,
            damID: damID,
            notes: notes,
            photoData: photoData
        )

        if let index = store.rabbits.firstIndex(where: { $0.id == updated.id }) {
            store.rabbits[index] = updated
        } else {
            store.rabbits.append(updated)
        }
        if let doc = store.pedigreeDocument(for: updated.id) {
            let parsed = PedigreeTextParser.parse(doc.extractedText)
            store.applyParsedPedigree(lineage: parsed.lineage, to: updated.id)
        }
        dismiss()
    }
}

struct PedigreeView: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbitID: UUID
    @State private var showFullScreen = false
    @State private var shareURL: URL?
    @State private var showEdit = false
    @State private var printURL: URL?

    private let certificateWidth: CGFloat = 1536
    private let certificateHeight: CGFloat = 1024
    private var rabbit: Rabbit? { store.rabbit(rabbitID) }

    var body: some View {
        Group {
            if let rabbit {
                VStack(spacing: 10) {
                    HStack(spacing: 10) {
                        Button { showEdit = true } label: {
                            Label("Edit", systemImage: "pencil")
                                .frame(maxWidth: .infinity)
                        }
                        Button { printPedigree(rabbit) } label: {
                            Label("Print", systemImage: "printer.fill")
                                .frame(maxWidth: .infinity)
                        }
                        Button { exportPDF(rabbit) } label: {
                            Label("Share", systemImage: "square.and.arrow.up")
                                .frame(maxWidth: .infinity)
                        }
                    }
                    .font(.subheadline.weight(.bold))
                    .foregroundStyle(.white)
                    .padding(8)
                    .background(Color.rfDeepGreen, in: RoundedRectangle(cornerRadius: 14, style: .continuous))
                    .padding(.horizontal, 10)

                    ZoomablePedigreeCanvas(
                        rabbit: rabbit,
                        certificateWidth: certificateWidth,
                        certificateHeight: certificateHeight,
                        fillWidth: true
                    )
                    .environmentObject(store)
                    .padding(.horizontal, 8)
                    .padding(.bottom, 12)
                }
                .background(Color(red: 0.88, green: 0.85, blue: 0.77))
                .navigationTitle("Pedigree")
                .navigationBarTitleDisplayMode(.inline)
                .rabbitFlowNavigationChrome()
                .toolbar {
                    ToolbarItem(placement: .topBarTrailing) {
                        Button { showFullScreen = true } label: {
                            Image(systemName: "arrow.up.left.and.arrow.down.right")
                        }
                        .accessibilityLabel("View pedigree full screen")
                    }
                }
                .fullScreenCover(isPresented: $showFullScreen) {
                    PedigreeFullScreenView(
                        rabbit: rabbit,
                        certificateWidth: certificateWidth,
                        certificateHeight: certificateHeight
                    )
                    .environmentObject(store)
                }
                .sheet(isPresented: $showEdit) {
                    NavigationStack { FiveGenerationPedigreeEditor(rabbitID: rabbitID) }
                        .environmentObject(store)
                }
                .sheet(isPresented: Binding(get: { shareURL != nil }, set: { if !$0 { shareURL = nil } })) {
                    if let url = shareURL { ShareSheet(items: [url]) }
                }
                .sheet(isPresented: Binding(get: { printURL != nil }, set: { if !$0 { printURL = nil } })) {
                    if let url = printURL {
                        PrintDocumentView(
                            url: url,
                            jobName: "RabbitFlow Pedigree - \(store.displayName(rabbit))"
                        )
                    }
                }
            } else {
                ContentUnavailableView("Rabbit Not Found", systemImage: "hare", description: Text("This rabbit record is no longer available."))
            }
        }
    }

    @MainActor private func makePDF(_ rabbit: Rabbit) -> URL? {
        let content = PedigreeCertificate(rabbit: rabbit).environmentObject(store).frame(width: certificateWidth, height: certificateHeight)
        let renderer = ImageRenderer(content: content)
        renderer.scale = 2
        guard let image = renderer.uiImage else { return nil }
        let url = FileManager.default.temporaryDirectory.appendingPathComponent("RabbitFlow_\(store.displayName(rabbit).replacingOccurrences(of: " ", with: "_"))_Pedigree.pdf")
        let pdf = UIGraphicsPDFRenderer(bounds: CGRect(x: 0, y: 0, width: certificateWidth, height: certificateHeight))
        do {
            try pdf.writePDF(to: url) { ctx in
                ctx.beginPage()
                image.draw(in: CGRect(x: 0, y: 0, width: certificateWidth, height: certificateHeight))
            }
            return url
        } catch {
            return nil
        }
    }

    @MainActor private func exportPDF(_ rabbit: Rabbit) {
        shareURL = makePDF(rabbit)
    }

    @MainActor private func printPedigree(_ rabbit: Rabbit) {
        printURL = makePDF(rabbit)
    }
}

private struct PrintDocumentView: UIViewControllerRepresentable {
    let url: URL
    let jobName: String

    func makeUIViewController(context: Context) -> UIViewController {
        PrintHostController(url: url, jobName: jobName)
    }

    func updateUIViewController(_ uiViewController: UIViewController, context: Context) {}

    private final class PrintHostController: UIViewController {
        let url: URL
        let jobName: String
        private var hasPresented = false

        init(url: URL, jobName: String) {
            self.url = url
            self.jobName = jobName
            super.init(nibName: nil, bundle: nil)
        }

        required init?(coder: NSCoder) { nil }

        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            guard !hasPresented else { return }
            hasPresented = true

            let controller = UIPrintInteractionController.shared
            let info = UIPrintInfo(dictionary: nil)
            info.outputType = .general
            info.jobName = jobName
            controller.printInfo = info
            controller.printingItem = url

            if UIDevice.current.userInterfaceIdiom == .pad {
                controller.present(from: view.bounds, in: view, animated: true, completionHandler: nil)
            } else {
                controller.present(animated: true, completionHandler: nil)
            }
        }
    }
}

private struct FiveGenerationPedigreeEditor: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let rabbitID: UUID
    @State private var names: [String: String] = [:]

    private var rabbit: Rabbit? { store.rabbit(rabbitID) }

    var body: some View {
        Form {
            Section {
                Text("Enter or correct any ancestor. RabbitFlow stores the full 5-generation family tree and uses it for the on-screen and printed pedigree.")
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            ForEach(1...5, id: \.self) { generation in
                Section("Generation \(generation)") {
                    ForEach(binaryPathKeys(depth: generation), id: \.self) { key in
                        TextField(relationLabel(key), text: binding(for: key))
                            .textInputAutocapitalization(.words)
                    }
                }
            }
        }
        .navigationTitle("Edit 5-Generation Pedigree")
        .navigationBarTitleDisplayMode(.inline)
        .rabbitFlowNavigationChrome()
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") { dismiss() }
            }
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") { save() }
            }
        }
        .onAppear { load() }
    }

    private func binding(for key: String) -> Binding<String> {
        Binding(
            get: { names[key, default: ""] },
            set: { names[key] = $0 }
        )
    }

    private func load() {
        guard let rabbit else { return }
        var result: [String: String] = [:]
        for depth in 1...5 {
            for key in binaryPathKeys(depth: depth) {
                let path = key.map { $0 == "s" ? AncestorSide.sire : AncestorSide.dam }
                if let ancestor = store.ancestor(of: rabbit, path: path) {
                    result[key] = store.displayName(ancestor)
                }
            }
        }
        names = result
    }

    private func save() {
        for depth in 1...5 {
            for key in binaryPathKeys(depth: depth) {
                store.setPedigreeAncestor(name: names[key, default: ""], path: key, rootRabbitID: rabbitID)
            }
        }
        dismiss()
    }

    private func binaryPathKeys(depth: Int) -> [String] {
        guard depth > 0 else { return [""] }
        return binaryPathKeys(depth: depth - 1).flatMap { [$0 + "s", $0 + "d"] }
    }

    private func relationLabel(_ key: String) -> String {
        key.map { $0 == "s" ? "Sire" : "Dam" }.joined(separator: " → ")
    }
}

private struct ZoomablePedigreeCanvas: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbit: Rabbit
    let certificateWidth: CGFloat
    let certificateHeight: CGFloat
    var fillWidth: Bool = false

    @State private var zoom: CGFloat = 1
    @State private var lastZoom: CGFloat = 1
    @State private var offset: CGSize = .zero
    @State private var lastOffset: CGSize = .zero

    var body: some View {
        GeometryReader { proxy in
            let horizontalInset: CGFloat = fillWidth ? 0 : 16
            let availableWidth = max(proxy.size.width - horizontalInset * 2, 1)
            let availableHeight = max(proxy.size.height - 16, 1)
            let widthScale = availableWidth / certificateWidth
            let heightScale = availableHeight / certificateHeight
            let fitScale = fillWidth ? widthScale : min(widthScale, heightScale)
            let effectiveScale = max(fitScale, 0.01) * zoom
            let fittedHeight = certificateHeight * fitScale
            let topY = max(fittedHeight / 2 + 4, 4)

            PedigreeCertificate(rabbit: rabbit)
                .environmentObject(store)
                .frame(width: certificateWidth, height: certificateHeight)
                .scaleEffect(effectiveScale)
                .position(
                    x: proxy.size.width / 2 + offset.width,
                    y: (fillWidth ? topY : proxy.size.height / 2) + offset.height
                )
                .contentShape(Rectangle())
                .gesture(
                    SimultaneousGesture(
                        MagnificationGesture()
                            .onChanged { value in
                                zoom = min(max(lastZoom * value, 1), 5)
                            }
                            .onEnded { _ in
                                lastZoom = zoom
                                if zoom <= 1.01 {
                                    withAnimation(.easeOut(duration: 0.18)) {
                                        zoom = 1
                                        lastZoom = 1
                                        offset = .zero
                                        lastOffset = .zero
                                    }
                                }
                            },
                        DragGesture()
                            .onChanged { value in
                                guard zoom > 1.01 else { return }
                                offset = CGSize(
                                    width: lastOffset.width + value.translation.width,
                                    height: lastOffset.height + value.translation.height
                                )
                            }
                            .onEnded { _ in
                                lastOffset = offset
                            }
                    )
                )
                .onTapGesture(count: 2) {
                    withAnimation(.easeInOut(duration: 0.2)) {
                        if zoom > 1.01 {
                            zoom = 1
                            lastZoom = 1
                            offset = .zero
                            lastOffset = .zero
                        } else {
                            zoom = 2
                            lastZoom = 2
                        }
                    }
                }
        }
        .clipped()
        .accessibilityLabel("RabbitFlow pedigree. Pinch to zoom and drag to pan.")
    }
}

private struct PedigreeFullScreenView: View {
    @EnvironmentObject var store: RabbitFlowStore
    @Environment(\.dismiss) private var dismiss
    let rabbit: Rabbit
    let certificateWidth: CGFloat
    let certificateHeight: CGFloat

    var body: some View {
        ZStack(alignment: .topTrailing) {
            Color(red: 0.10, green: 0.18, blue: 0.13).ignoresSafeArea()

            ZoomablePedigreeCanvas(
                rabbit: rabbit,
                certificateWidth: certificateWidth,
                certificateHeight: certificateHeight,
                fillWidth: false
            )
            .environmentObject(store)
            .ignoresSafeArea(edges: .bottom)

            Button {
                dismiss()
            } label: {
                Image(systemName: "xmark")
                    .font(.headline.weight(.bold))
                    .foregroundStyle(.white)
                    .frame(width: 44, height: 44)
                    .background(.black.opacity(0.55), in: Circle())
            }
            .padding(16)
            .accessibilityLabel("Close full screen pedigree")
        }
        .onAppear { requestOrientation(.landscape) }
        .onDisappear { requestOrientation(.portrait) }
    }

    private func requestOrientation(_ orientations: UIInterfaceOrientationMask) {
        guard let scene = UIApplication.shared.connectedScenes.compactMap({ $0 as? UIWindowScene }).first else { return }
        scene.requestGeometryUpdate(.iOS(interfaceOrientations: orientations))
    }
}

private struct ShareSheet: UIViewControllerRepresentable {
    let items: [Any]
    func makeUIViewController(context: Context) -> UIActivityViewController { UIActivityViewController(activityItems: items, applicationActivities: nil) }
    func updateUIViewController(_ uiViewController: UIActivityViewController, context: Context) {}
}


private struct PedigreeCertificate: View {
    @EnvironmentObject var store: RabbitFlowStore
    let rabbit: Rabbit

    private let parchment = Color(red: 0.968, green: 0.944, blue: 0.875)
    private let panel = Color(red: 0.992, green: 0.979, blue: 0.935)
    private let ink = Color.rfDeepGreen
    private let accent = Color(red: 0.32, green: 0.28, blue: 0.18)

    var body: some View {
        ZStack {
            Image("PedigreeMasterBackground")
                .resizable()
                .scaledToFill()
                .frame(width: 1536, height: 1024)

            // Locked master: circular RabbitFlow watermark centered behind the pedigree tree.
            Image("RabbitFlowPedigreeWatermarkCircular")
                .resizable()
                .scaledToFit()
                .frame(width: 520, height: 520)
                .clipShape(Circle())
                .opacity(0.07)
                .offset(x: 65, y: 35)

            subjectCard
                .frame(width: 290, height: 420)
                .position(x: 197, y: 465)

            lineageTree
                .frame(width: 1065, height: 650)
                .position(x: 930, y: 522)

            HStack(spacing: 34) {
                signatureBlock(title: "BREEDER SIGNATURE", value: rabbit.breederSource)
                signatureBlock(title: "DATE", value: Date.now.formatted(date: .numeric, time: .omitted))
                signatureBlock(title: "SYSTEM GENERATED • RABBITFLOW APP", value: "RabbitFlow")
            }
            .position(x: 700, y: 892)
        }
        .frame(width: 1536, height: 1024)
        .foregroundStyle(Color.black.opacity(0.9))
        .clipped()
    }

    private var certificateHeader: some View {
        HStack(alignment: .center, spacing: 16) {
            HStack(spacing: 10) {
                Image("RabbitFlowPedigreeLogo")
                    .resizable()
                    .scaledToFit()
                    .frame(width: 82, height: 82)
                    .clipShape(RoundedRectangle(cornerRadius: 15, style: .continuous))

                VStack(alignment: .leading, spacing: 1) {
                    HStack(spacing: 0) {
                        Text("Rabbit").foregroundStyle(Color.black.opacity(0.9))
                        Text("Flow").foregroundStyle(ink)
                    }
                    .font(.system(size: 31, weight: .black, design: .serif))
                    Text("MANAGE • TRACK • BREED • GROW")
                        .font(.system(size: 9.3, weight: .bold))
                        .tracking(1.0)
                        .foregroundStyle(ink.opacity(0.84))
                }
            }
            .frame(width: 315, alignment: .leading)

            VStack(spacing: 2) {
                HStack(spacing: 10) {
                    Rectangle().fill(ink).frame(width: 72, height: 2)
                    Text("PEDIGREE")
                        .font(.system(size: 47, weight: .black, design: .serif))
                        .foregroundStyle(ink)
                    Rectangle().fill(ink).frame(width: 72, height: 2)
                }
                Text(headerSubtitle)
                    .font(.system(size: 12.5, weight: .bold, design: .serif))
                    .tracking(1.7)
                    .foregroundStyle(ink.opacity(0.84))
                    .lineLimit(1)
                    .minimumScaleFactor(0.62)
                Text("Better Rabbits. A Brighter Tomorrow.")
                    .font(.system(size: 20, weight: .medium, design: .serif).italic())
                    .foregroundStyle(accent.opacity(0.9))
            }
            .frame(maxWidth: .infinity)

            VStack(alignment: .trailing, spacing: 3) {
                Text("HEALTHY STOCK")
                Text("STRONG LINES")
                Text("PRODUCTIVE RABBITS")
                Text("BUILT FOR TOMORROW")
                HStack(spacing: 6) {
                    Image(systemName: "pawprint.fill")
                    Text("RABBITFLOW • EST. 2026")
                }
                .padding(.top, 3)
            }
            .font(.system(size: 9, weight: .bold, design: .serif))
            .tracking(1.3)
            .foregroundStyle(ink)
            .frame(width: 235, alignment: .trailing)
        }
    }

    private var headerSubtitle: String {
        let breeder = rabbit.breederSource.trimmingCharacters(in: .whitespacesAndNewlines)
        return breeder.isEmpty ? "RABBITFLOW" : breeder.uppercased()
    }

    private var subjectCard: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("PEDIGREE OF:")
                .font(.system(size: 10.5, weight: .black, design: .serif))
                .foregroundStyle(ink)

            subjectPhoto
                .frame(height: 160)
                .clipShape(RoundedRectangle(cornerRadius: 7, style: .continuous))
                .overlay(RoundedRectangle(cornerRadius: 7).stroke(ink.opacity(0.4), lineWidth: 1))

            Text(store.displayName(rabbit).uppercased())
                .font(.system(size: 25, weight: .black, design: .serif))
                .foregroundStyle(ink)
                .minimumScaleFactor(0.6)
                .lineLimit(2)

            certificateLine("Breed", rabbit.breed)
            certificateLine("Sex", rabbit.sex.rawValue)
            certificateLine("Color", rabbit.variety)
            certificateLine("Date of Birth", rabbit.dateOfBirth.formatted(date: .numeric, time: .omitted))
            certificateLine("Registration #", rabbit.registrationNumber.isEmpty ? "N/A" : rabbit.registrationNumber)
            certificateLine("Tattoo / ID", rabbit.tattooID.isEmpty ? "N/A" : rabbit.tattooID)
            certificateLine("Breeder / Source", rabbit.breederSource.isEmpty ? "N/A" : rabbit.breederSource)

            if !rabbit.notes.isEmpty {
                Divider().overlay(ink.opacity(0.3))
                Text("NOTES")
                    .font(.system(size: 8.5, weight: .bold))
                    .foregroundStyle(ink)
                Text(rabbit.notes)
                    .font(.system(size: 9.5))
                    .lineLimit(3)
                    .minimumScaleFactor(0.7)
            }

            Spacer(minLength: 0)
        }
        .padding(11)
        .frame(maxHeight: .infinity, alignment: .top)
        .background(panel.opacity(0.72), in: RoundedRectangle(cornerRadius: 7))
        .overlay(RoundedRectangle(cornerRadius: 7).stroke(ink.opacity(0.48), lineWidth: 1.1))
    }

    @ViewBuilder
    private var subjectPhoto: some View {
        if let data = rabbit.photoData, let image = UIImage(data: data) {
            Image(uiImage: image).resizable().scaledToFill()
        } else {
            ZStack {
                Color.rfWarmCream
                Image("RabbitFlowPedigreeLogo")
                    .resizable()
                    .scaledToFit()
                    .padding(22)
                    .opacity(0.7)
            }
        }
    }

    private func certificateLine(_ label: String, _ value: String) -> some View {
        HStack(alignment: .firstTextBaseline, spacing: 5) {
            Text("\(label):")
                .font(.system(size: 8.7, weight: .bold))
            Text(value)
                .font(.system(size: 9.8, weight: .semibold))
                .lineLimit(1)
                .minimumScaleFactor(0.62)
            Spacer(minLength: 0)
        }
    }

    private var lineageTree: some View {
        HStack(spacing: 5) {
            ancestorGenerationColumn(title: "1ST GENERATION", depth: 1)
            ancestorGenerationColumn(title: "2ND GENERATION", depth: 2)
            ancestorGenerationColumn(title: "3RD GENERATION", depth: 3)
            ancestorGenerationColumn(title: "4TH GENERATION", depth: 4)
            ancestorGenerationColumn(title: "5TH GENERATION", depth: 5)
        }
        .padding(4)
    }

    private func ancestorGenerationColumn(title: String, depth: Int) -> some View {
        let paths = binaryPaths(depth: depth)
        return VStack(spacing: 0) {
            Text(title)
                .font(.system(size: depth >= 4 ? 7.2 : 8.5, weight: .black))
                .foregroundStyle(.white)
                .minimumScaleFactor(0.65)
                .lineLimit(1)
                .frame(maxWidth: .infinity)
                .frame(height: 24)
                .background(ink)

            VStack(spacing: depth >= 4 ? 1.2 : 2.5) {
                ForEach(Array(paths.enumerated()), id: \.offset) { _, path in
                    densePedigreeNode(path: path, depth: depth)
                        .frame(maxHeight: .infinity)
                }
            }
            .padding(depth >= 4 ? 2 : 3)
        }
        .frame(maxHeight: .infinity)
        .background(panel.opacity(0.62))
        .overlay(Rectangle().stroke(ink.opacity(0.48), lineWidth: 0.8))
    }

    private func densePedigreeNode(path: [AncestorSide], depth: Int) -> some View {
        let ancestor = store.ancestor(of: rabbit, path: path)
        let veryDense = depth >= 4
        return HStack(spacing: 3) {
            if depth <= 2 {
                ancestorPhoto(ancestor, size: depth == 1 ? 42 : 28)
            }

            VStack(alignment: .leading, spacing: 0) {
                Text(ancestor.map(store.displayName) ?? "UNKNOWN")
                    .font(.system(size: depth == 1 ? 10.5 : depth == 2 ? 8.5 : depth == 3 ? 6.9 : depth == 4 ? 5.7 : 4.9, weight: .bold, design: .serif))
                    .lineLimit(1)
                    .minimumScaleFactor(0.45)

                if let ancestor {
                    if !veryDense {
                        Text(ancestor.registrationNumber.isEmpty ? ancestor.breed : "# \(ancestor.registrationNumber)")
                            .font(.system(size: depth == 1 ? 6.8 : depth == 2 ? 5.7 : 4.8))
                            .foregroundStyle(.secondary)
                            .lineLimit(1)
                            .minimumScaleFactor(0.5)
                    }
                } else if !veryDense {
                    Text(relationName(path))
                        .font(.system(size: depth <= 2 ? 5.8 : 4.5, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                        .minimumScaleFactor(0.5)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(.horizontal, veryDense ? 2 : 3)
        .padding(.vertical, veryDense ? 0 : 1)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.30), in: RoundedRectangle(cornerRadius: veryDense ? 2 : 4))
        .overlay(RoundedRectangle(cornerRadius: veryDense ? 2 : 4).stroke(ink.opacity(0.25), lineWidth: 0.45))
    }

    private func pedigreeNode(path: [AncestorSide], compact: Bool) -> some View {
        let ancestor = store.ancestor(of: rabbit, path: path)
        return HStack(spacing: compact ? 5 : 7) {
            ancestorPhoto(ancestor, size: compact ? 42 : 60)
            VStack(alignment: .leading, spacing: compact ? 0 : 1) {
                Text(relationName(path))
                    .font(.system(size: compact ? 6.5 : 8.3, weight: .black, design: .serif))
                    .foregroundStyle(ink)
                    .lineLimit(1)
                Text(ancestor.map(store.displayName) ?? "UNKNOWN")
                    .font(.system(size: compact ? 9.0 : 13.0, weight: .bold, design: .serif))
                    .lineLimit(compact ? 1 : 2)
                    .minimumScaleFactor(0.55)
                if let ancestor {
                    Text(ancestor.breed)
                        .font(.system(size: compact ? 6.8 : 8.5))
                        .lineLimit(1)
                    if !ancestor.variety.isEmpty {
                        Text(ancestor.variety)
                            .font(.system(size: compact ? 6.4 : 8.0))
                            .lineLimit(1)
                    }
                    Text(ancestor.registrationNumber.isEmpty ? "Reg #: N/A" : "Reg #: \(ancestor.registrationNumber)")
                        .font(.system(size: compact ? 6.2 : 7.8))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                } else {
                    Text("UNVERIFIED LINEAGE")
                        .font(.system(size: compact ? 6.0 : 7.6, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(compact ? 5 : 7)
        .background(panel.opacity(0.90), in: RoundedRectangle(cornerRadius: 6, style: .continuous))
        .overlay(RoundedRectangle(cornerRadius: 6).stroke(ink.opacity(0.62), lineWidth: 1.0))
        .shadow(color: .black.opacity(0.06), radius: 2, y: 1)
    }

    private func ancestorColumn(title: String, paths: [[AncestorSide]], compact: Bool) -> some View {
        VStack(spacing: 0) {
            Text(title)
                .font(.system(size: title.count > 15 ? 9 : 10.5, weight: .black))
                .foregroundStyle(.white)
                .tracking(0.5)
                .frame(maxWidth: .infinity)
                .frame(height: 31)
                .background(ink)

            VStack(spacing: compact ? 4 : 6) {
                ForEach(Array(paths.enumerated()), id: \.offset) { _, path in
                    ancestorCard(path: path, compact: compact)
                        .frame(maxHeight: .infinity)
                }
            }
            .padding(5)
        }
        .frame(maxHeight: .infinity)
        .background(panel.opacity(0.6))
        .overlay(Rectangle().stroke(ink.opacity(0.48), lineWidth: 1))
    }

    private func ancestorCard(path: [AncestorSide], compact: Bool) -> some View {
        let ancestor = store.ancestor(of: rabbit, path: path)

        return HStack(spacing: compact ? 5 : 7) {
            ancestorPhoto(ancestor, size: compact ? 35 : 50)

            VStack(alignment: .leading, spacing: compact ? 0 : 1) {
                Text(relationName(path))
                    .font(.system(size: compact ? 6.2 : 7.2, weight: .bold))
                    .foregroundStyle(ink.opacity(0.72))
                    .lineLimit(1)
                    .minimumScaleFactor(0.5)

                Text(ancestor.map(store.displayName) ?? "UNKNOWN")
                    .font(.system(size: compact ? 8.0 : 10.3, weight: .bold, design: .serif))
                    .lineLimit(2)
                    .minimumScaleFactor(0.5)

                if let ancestor {
                    Text(ancestor.breed)
                        .font(.system(size: compact ? 6.2 : 7.6))
                        .lineLimit(1)
                    Text(ancestor.variety.isEmpty ? "Color: N/A" : ancestor.variety)
                        .font(.system(size: compact ? 5.9 : 7.1))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                    Text(ancestor.registrationNumber.isEmpty ? "Reg #: N/A" : "Reg #: \(ancestor.registrationNumber)")
                        .font(.system(size: compact ? 5.8 : 7.0))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                } else {
                    Text("UNVERIFIED LINEAGE")
                        .font(.system(size: compact ? 5.8 : 7.0, weight: .semibold))
                        .foregroundStyle(.secondary)
                        .lineLimit(1)
                }
            }
            Spacer(minLength: 0)
        }
        .padding(compact ? 4 : 6)
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .leading)
        .background(Color.white.opacity(0.3), in: RoundedRectangle(cornerRadius: 5))
        .overlay(RoundedRectangle(cornerRadius: 5).stroke(ink.opacity(0.27), lineWidth: 0.7))
    }

    @ViewBuilder
    private func ancestorPhoto(_ ancestor: Rabbit?, size: CGFloat) -> some View {
        if let ancestor, let data = ancestor.photoData, let image = UIImage(data: data) {
            Image(uiImage: image)
                .resizable()
                .scaledToFill()
                .frame(width: size, height: size)
                .clipShape(RoundedRectangle(cornerRadius: 4))
        } else {
            ZStack {
                Color.rfWarmCream
                Image(systemName: "hare.fill")
                    .font(.system(size: size * 0.45, weight: .semibold))
                    .foregroundStyle(ink.opacity(0.7))
            }
            .frame(width: size, height: size)
            .clipShape(RoundedRectangle(cornerRadius: 4))
        }
    }

    private func relationName(_ path: [AncestorSide]) -> String {
        if path.count == 1 { return path[0] == .sire ? "Sire" : "Dam" }
        let names = path.map { $0 == .sire ? "Sire" : "Dam" }
        if path.count == 2 { return "\(names[0])’s \(names[1])" }
        if path.count == 3 { return path.last == .sire ? "Grand Sire" : "Grand Dam" }
        return names.joined(separator: " / ")
    }

    private func binaryPaths(depth: Int) -> [[AncestorSide]] {
        guard depth > 0 else { return [[]] }
        return binaryPaths(depth: depth - 1).flatMap { path in [path + [.sire], path + [.dam]] }
    }

    private var certificateFooter: some View {
        ZStack(alignment: .bottom) {
            // Farm-and-rabbit silhouette band from the locked pedigree master.
            HStack(alignment: .bottom, spacing: 9) {
                ForEach(0..<9, id: \.self) { index in
                    Image(systemName: index.isMultiple(of: 3) ? "hare.fill" : "leaf.fill")
                        .font(.system(size: index.isMultiple(of: 3) ? 18 : 12, weight: .bold))
                        .foregroundStyle(ink.opacity(0.52))
                }
                Spacer(minLength: 8)
                Image(systemName: "house.fill")
                    .font(.system(size: 28, weight: .bold))
                    .foregroundStyle(ink.opacity(0.58))
                Image(systemName: "tree.fill")
                    .font(.system(size: 23, weight: .bold))
                    .foregroundStyle(ink.opacity(0.52))
            }
            .padding(.horizontal, 8)
            .padding(.bottom, 2)

            VStack(spacing: 5) {
                Divider().overlay(ink.opacity(0.46))
                HStack(alignment: .center, spacing: 16) {
                    ZStack {
                        Circle()
                            .fill(LinearGradient(colors: [Color(red: 0.96, green: 0.79, blue: 0.28), Color(red: 0.62, green: 0.39, blue: 0.07)], startPoint: .topLeading, endPoint: .bottomTrailing))
                            .overlay(Circle().stroke(Color(red: 0.38, green: 0.22, blue: 0.03), lineWidth: 2.5))
                        Circle()
                            .stroke(Color.white.opacity(0.35), style: StrokeStyle(lineWidth: 1.2, dash: [3, 2]))
                            .padding(5)
                        Image("RabbitFlowPedigreeLogo")
                            .resizable()
                            .scaledToFit()
                            .padding(10)
                    }
                    .frame(width: 66, height: 66)

                    signatureBlock(title: "BREEDER SIGNATURE", value: rabbit.breederSource)
                    signatureBlock(title: "DATE", value: Date.now.formatted(date: .numeric, time: .omitted))
                    signatureBlock(title: "SYSTEM GENERATED • RABBITFLOW APP", value: "RabbitFlow")

                    Spacer(minLength: 10)

                    VStack(alignment: .trailing, spacing: 1) {
                        Text("HEALTHIER RABBITS")
                        Text("STRONGER TOMORROWS")
                    }
                    .font(.system(size: 7.6, weight: .bold, design: .serif))
                    .tracking(1.1)
                    .foregroundStyle(ink)
                }

                HStack(spacing: 12) {
                    Rectangle().fill(ink.opacity(0.45)).frame(height: 0.8)
                    Text("MANAGE • TRACK • BREED • GROW")
                        .font(.system(size: 8.5, weight: .bold, design: .serif))
                        .tracking(2.0)
                        .foregroundStyle(ink)
                    Rectangle().fill(ink.opacity(0.45)).frame(height: 0.8)
                }
                .padding(.horizontal, 210)
            }
            .padding(.bottom, 16)
        }
    }

    private func signatureBlock(title: String, value: String) -> some View {
        VStack(alignment: .leading, spacing: 2) {
            Text(value.isEmpty ? " " : value)
                .font(.system(size: 9.2, weight: .semibold, design: .serif).italic())
                .lineLimit(1)
                .minimumScaleFactor(0.6)
            Rectangle().fill(Color.black.opacity(0.55)).frame(width: 135, height: 0.8)
            Text(title)
                .font(.system(size: 6.8, weight: .bold))
                .tracking(0.7)
        }
    }
}
