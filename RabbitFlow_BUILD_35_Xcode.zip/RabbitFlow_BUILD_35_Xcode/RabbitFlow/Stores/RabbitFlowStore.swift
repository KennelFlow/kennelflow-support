import Foundation
import SwiftUI

@MainActor
final class RabbitFlowStore: ObservableObject {
    @Published var rabbits: [Rabbit] = [] { didSet { scheduleSave() } }
    @Published var breedings: [BreedingRecord] = [] { didSet { scheduleSave() } }
    @Published var litters: [LitterRecord] = [] { didSet { scheduleSave() } }
    @Published var cages: [CageRecord] = [] { didSet { scheduleSave() } }
    @Published var duties: [DutyRecord] = [] { didSet { scheduleSave() } }
    @Published var health: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var feeding: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var growOut: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var sales: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var customers: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var expenses: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var inventory: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var calendarItems: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var nestBox: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var pedigreeDocuments: [PedigreeDocument] = [] { didSet { scheduleSave() } }
    @Published var reports: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var photosDocuments: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var notesRecords: [SimpleRecord] = [] { didSet { scheduleSave() } }
    @Published var smartAccess: [SmartAccessRecord] = [] { didSet { scheduleSave() } }

    private let saveURL: URL
    private var isLoading = false
    private var pendingSaveTask: Task<Void, Never>?

    init() {
        let docs = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first ?? FileManager.default.temporaryDirectory
        saveURL = docs.appendingPathComponent("rabbitflow_private_data.json")
        load()
    }

    deinit {
        pendingSaveTask?.cancel()
    }

    struct Snapshot: Codable, Sendable {
        var rabbits: [Rabbit]
        var breedings: [BreedingRecord]
        var litters: [LitterRecord]
        var cages: [CageRecord]
        var duties: [DutyRecord]
        var health: [SimpleRecord]
        var feeding: [SimpleRecord]
        var growOut: [SimpleRecord]
        var sales: [SimpleRecord]
        var customers: [SimpleRecord]
        var expenses: [SimpleRecord]
        var inventory: [SimpleRecord]
        var calendarItems: [SimpleRecord]
        var nestBox: [SimpleRecord]
        var pedigreeDocuments: [PedigreeDocument]?
        var reports: [SimpleRecord]?
        var photosDocuments: [SimpleRecord]?
        var notesRecords: [SimpleRecord]?
        var smartAccess: [SmartAccessRecord]?
    }

    private func scheduleSave() {
        guard !isLoading else { return }
        pendingSaveTask?.cancel()
        let snapshot = currentSnapshot()
        let url = saveURL

        pendingSaveTask = Task {
            try? await Task.sleep(for: .milliseconds(180))
            guard !Task.isCancelled else { return }
            do {
                let data = try JSONEncoder().encode(snapshot)
                try data.write(to: url, options: .atomic)
            } catch {
                print("RabbitFlow save error: \(error)")
            }
        }
    }

    private func currentSnapshot() -> Snapshot {
        Snapshot(
            rabbits: rabbits,
            breedings: breedings,
            litters: litters,
            cages: cages,
            duties: duties,
            health: health,
            feeding: feeding,
            growOut: growOut,
            sales: sales,
            customers: customers,
            expenses: expenses,
            inventory: inventory,
            calendarItems: calendarItems,
            nestBox: nestBox,
            pedigreeDocuments: pedigreeDocuments,
            reports: reports,
            photosDocuments: photosDocuments,
            notesRecords: notesRecords,
            smartAccess: smartAccess
        )
    }

    private func load() {
        guard let data = try? Data(contentsOf: saveURL) else { return }
        isLoading = true
        defer { isLoading = false }
        guard let snapshot = try? JSONDecoder().decode(Snapshot.self, from: data) else { return }
        rabbits = snapshot.rabbits
        breedings = snapshot.breedings
        litters = snapshot.litters
        cages = snapshot.cages
        duties = snapshot.duties
        health = snapshot.health
        feeding = snapshot.feeding
        growOut = snapshot.growOut
        sales = snapshot.sales
        customers = snapshot.customers
        expenses = snapshot.expenses
        inventory = snapshot.inventory
        calendarItems = snapshot.calendarItems
        nestBox = snapshot.nestBox
        pedigreeDocuments = snapshot.pedigreeDocuments ?? []
        reports = snapshot.reports ?? []
        photosDocuments = snapshot.photosDocuments ?? []
        notesRecords = snapshot.notesRecords ?? []
        smartAccess = snapshot.smartAccess ?? []
    }

    func rabbit(_ id: UUID?) -> Rabbit? {
        guard let id else { return nil }
        return rabbits.first(where: { $0.id == id })
    }

    func rabbitName(_ id: UUID?) -> String {
        guard let rabbit = rabbit(id) else { return "Not assigned" }
        return displayName(rabbit)
    }

    func displayName(_ rabbit: Rabbit) -> String {
        if !rabbit.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return rabbit.name }
        if !rabbit.tattooID.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { return rabbit.tattooID }
        return "Unnamed Rabbit"
    }

    func ancestor(of rabbit: Rabbit?, path: [AncestorSide]) -> Rabbit? {
        var current = rabbit
        for side in path {
            guard let item = current else { return nil }
            current = self.rabbit(side == .sire ? item.sireID : item.damID)
        }
        return current
    }

    func lookupScan(_ value: String) -> ScanDestination? {
        let clean = value
            .trimmingCharacters(in: .whitespacesAndNewlines)
            .replacingOccurrences(of: "rabbitflow://tag/", with: "")
        if let access = smartAccess.first(where: { $0.code.caseInsensitiveCompare(clean) == .orderedSame }) {
            switch access.entityType {
            case "Rabbit":
                if let id = access.entityID { return .rabbit(id) }
            case "Cage / Hutch":
                if let id = access.entityID { return .cage(id) }
            default:
                return .smartAccess(access.id)
            }
        }
        if let cage = cages.first(where: {
            $0.qrValue.caseInsensitiveCompare(value) == .orderedSame ||
            $0.nfcValue.caseInsensitiveCompare(value) == .orderedSame ||
            $0.qrValue.caseInsensitiveCompare(clean) == .orderedSame ||
            $0.nfcValue.caseInsensitiveCompare(clean) == .orderedSame
        }) { return .cage(cage.id) }
        if let id = UUID(uuidString: clean), rabbits.contains(where: { $0.id == id }) { return .rabbit(id) }
        return nil
    }

    func accessRecord(_ id: UUID) -> SmartAccessRecord? {
        smartAccess.first(where: { $0.id == id })
    }

    @discardableResult
    func ensureSmartAccess(label: String, entityType: String, entityID: UUID?, entityName: String, notes: String = "") -> SmartAccessRecord {
        if let entityID,
           let existing = smartAccess.first(where: { $0.entityType == entityType && $0.entityID == entityID }) {
            return existing
        }
        let record = SmartAccessRecord(label: label, entityType: entityType, entityID: entityID, entityName: entityName, notes: notes)
        smartAccess.append(record)
        syncLegacyCageValues(for: record)
        return record
    }

    func updateSmartAccess(_ record: SmartAccessRecord) {
        guard let index = smartAccess.firstIndex(where: { $0.id == record.id }) else { return }
        let old = smartAccess[index]
        if old.entityType == "Cage / Hutch", old.entityID != record.entityID {
            clearLegacyCageValues(for: old.entityID)
        }
        if let entityID = record.entityID,
           let conflict = smartAccess.firstIndex(where: { $0.id != record.id && $0.entityType == record.entityType && $0.entityID == entityID }) {
            let duplicate = smartAccess.remove(at: conflict)
            if duplicate.entityType == "Cage / Hutch" { clearLegacyCageValues(for: duplicate.entityID) }
        }
        if let freshIndex = smartAccess.firstIndex(where: { $0.id == record.id }) {
            smartAccess[freshIndex] = record
        }
        syncLegacyCageValues(for: record)
    }

    func removeSmartAccess(_ id: UUID) {
        guard let record = smartAccess.first(where: { $0.id == id }) else { return }
        smartAccess.removeAll { $0.id == id }
        if record.entityType == "Cage / Hutch" { clearLegacyCageValues(for: record.entityID) }
    }

    private func syncLegacyCageValues(for record: SmartAccessRecord) {
        guard record.entityType == "Cage / Hutch", let cageID = record.entityID,
              let index = cages.firstIndex(where: { $0.id == cageID }) else { return }
        cages[index].qrValue = record.accessLink
        cages[index].nfcValue = record.accessLink
    }

    private func clearLegacyCageValues(for cageID: UUID?) {
        guard let cageID, let index = cages.firstIndex(where: { $0.id == cageID }) else { return }
        cages[index].qrValue = ""
        cages[index].nfcValue = ""
    }

    func pedigreeDocument(for rabbitID: UUID) -> PedigreeDocument? {
        pedigreeDocuments.filter { $0.rabbitID == rabbitID }.sorted { $0.importedAt > $1.importedAt }.first
    }

    func savePedigreeDocument(_ document: PedigreeDocument) {
        pedigreeDocuments.removeAll { $0.rabbitID == document.rabbitID }
        pedigreeDocuments.append(document)
    }

    func applyParsedPedigree(sireName: String?, damName: String?, to rabbitID: UUID) {
        var lineage: [String: String] = [:]
        if let sireName, !sireName.isEmpty { lineage["s"] = sireName }
        if let damName, !damName.isEmpty { lineage["d"] = damName }
        applyParsedPedigree(lineage: lineage, to: rabbitID)
    }

    /// Applies any ancestors confidently recognized from an imported pedigree.
    /// Keys use s/d paths: s = sire, d = dam, ss = sire's sire, sd = sire's dam, etc.
    func applyParsedPedigree(lineage: [String: String], to rabbitID: UUID) {
        guard rabbits.contains(where: { $0.id == rabbitID }) else { return }
        for path in lineage.keys.sorted(by: { $0.count < $1.count }) {
            guard let name = lineage[path]?.trimmingCharacters(in: .whitespacesAndNewlines), !name.isEmpty else { continue }
            linkImportedAncestor(name: name, path: path, rootRabbitID: rabbitID)
        }
    }

    private func linkImportedAncestor(name: String, path: String, rootRabbitID: UUID) {
        guard let side = path.last, side == "s" || side == "d" else { return }
        let parentPath = String(path.dropLast())
        let childID: UUID
        if parentPath.isEmpty {
            childID = rootRabbitID
        } else if let resolved = rabbitID(atPedigreePath: parentPath, rootRabbitID: rootRabbitID) {
            childID = resolved
        } else {
            return
        }

        guard let childIndex = rabbits.firstIndex(where: { $0.id == childID }) else { return }
        let sex: RabbitSex = side == "s" ? .buck : .doe
        let breed = rabbits[childIndex].breed
        let existing = rabbits.first(where: {
            displayName($0).localizedCaseInsensitiveCompare(name) == .orderedSame && $0.sex == sex
        })
        let ancestor = existing ?? Rabbit(
            name: name,
            tattooID: "",
            sex: sex,
            dateOfBirth: Date(),
            breed: breed,
            variety: "",
            weight: 0,
            status: .active,
            registrationNumber: "",
            breederSource: "Imported pedigree",
            purchasePrice: 0,
            cageID: nil,
            sireID: nil,
            damID: nil,
            notes: "Created automatically from imported pedigree. Verify imported details before printing."
        )
        if existing == nil { rabbits.append(ancestor) }
        if side == "s" { rabbits[childIndex].sireID = ancestor.id }
        else { rabbits[childIndex].damID = ancestor.id }
    }



    func setPedigreeAncestor(name: String, path: String, rootRabbitID: UUID) {
        let clean = name.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !path.isEmpty, let side = path.last, side == "s" || side == "d" else { return }

        let parentPath = String(path.dropLast())
        let childID: UUID
        if parentPath.isEmpty {
            childID = rootRabbitID
        } else if let resolved = rabbitID(atPedigreePath: parentPath, rootRabbitID: rootRabbitID) {
            childID = resolved
        } else {
            return
        }

        guard let childIndex = rabbits.firstIndex(where: { $0.id == childID }) else { return }

        if clean.isEmpty {
            if side == "s" { rabbits[childIndex].sireID = nil }
            else { rabbits[childIndex].damID = nil }
            return
        }

        linkImportedAncestor(name: clean, path: path, rootRabbitID: rootRabbitID)
    }

    private func rabbitID(atPedigreePath path: String, rootRabbitID: UUID) -> UUID? {
        var currentID: UUID? = rootRabbitID
        for side in path {
            guard let id = currentID, let item = rabbit(id) else { return nil }
            currentID = side == "s" ? item.sireID : item.damID
        }
        return currentID
    }
}

enum AncestorSide: Sendable {
    case sire
    case dam
}

enum ScanDestination: Hashable {
    case rabbit(UUID)
    case cage(UUID)
    case smartAccess(UUID)
}
